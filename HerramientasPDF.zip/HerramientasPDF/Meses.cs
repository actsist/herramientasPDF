﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Data.SQLite;
using Utilities;

namespace Entity
{
    /// <summary>
    /// Summary description for Prospecto
    /// </summary>
    public class Mes
    {
        public string mes { get; set; }
        public string mesMMMYYYY { get; set; }

        public Mes(SQLiteDataReader reader)
        {
            mes = reader["mes"].ToString();
            mesMMMYYYY = reader["mesMMMYYYY"].ToString();
        }
        public Mes()
        {
            mes = "";
            mesMMMYYYY = "";
        }
    }
    public class Meses
    {
        public static string GetMesAnterior(string mesActual)
        {
            string mesAnterior = "";
            List<Mes> listaMeses = GetMes();
            foreach (Mes mes in listaMeses)
            {
                if (mes.mes == mesActual)
                    break;
                mesAnterior = mes.mes;
            }
            return mesAnterior;
        }

        public static string GetMMMYYYY(string mes)
        {
            if (mes == "")
                return "";

            string sql = "Select MesMMMYYYY From Meses Where mes='" + mes + "'";
            return Database.ExecuteScalarCmd(sql);
        }

        public static List<Mes> GetMes()
        {
            string sql = "Select * From Meses Order by mes";

            List<Mes> meses = new List<Mes>();
            Mes mes = new Mes();
            mes.mes = "";
            mes.mesMMMYYYY = "Todo el periodo";
            meses.Add(mes);
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                    meses.Add(new Mes(reader));
            }
            return meses;
        }

        public static List<string> GetListaMeses(string mesInicial, string mesFinal)
        {
            string sql = "Select Mes From Meses WHERE '@mesInicial' <= mes AND mes <= '@mesFinal' Order by mes";
            sql = sql.Replace("@mesInicial", mesInicial);
            sql = sql.Replace("@mesFinal", mesFinal);

            List<string> meses = new List<string>();
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                    meses.Add(reader["mes"].ToString());
            }
            return meses;
        }

        public static List<Mes> GetMeses(string mesInicial, string mesFinal)
        {
            string sql = "Select mes,mesMMMYYYY From Meses WHERE '@mesInicial' <= mes AND mes <= '@mesFinal' Order by mes";
            sql = sql.Replace("@mesInicial", mesInicial);
            sql = sql.Replace("@mesFinal", mesFinal);

            List<Mes> meses = new List<Mes>();
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                    meses.Add(new Mes(reader));
            }
            return meses;
        }

        public static bool MesConsiderado(string mes, string mesInicial, string mesFinal)
        {
            string sql = "SELECT mes FROM  Meses WHERE ('@mesInicial' <= '@mes' AND '@mes' <= '@mesFinal')";
            sql = sql.Replace("@mesInicial", mesInicial);
            sql = sql.Replace("@mesFinal", mesFinal);
            sql = sql.Replace("@mes", mes);
            bool mesConsiderado;
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                {
                    if (reader["mes"].ToString() != "")
                        mesConsiderado = true;
                    else
                        mesConsiderado = false;
                }
                else
                    mesConsiderado = false;
            }
            return mesConsiderado;
        }
    }
}
