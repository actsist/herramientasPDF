﻿using Entity;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Security.Cryptography;
using System.Windows.Forms;
using Utilities;

namespace ArchivoHistorico
{
    public partial class FrmMain : Form
    {
        bool cargaMasiva = false;

        public FrmMain()
        {
            InitializeComponent();
        }
        private void FrmMain_Load(object sender, EventArgs e)
        {
            this.Text += " Usuario:" + Environment.UserName;
            picFirma.Image = System.Drawing.Image.FromFile(Path.Combine(Directory.GetCurrentDirectory(), "Imagenes", "firma.jpg"));

            Utilerias.directorioUnzip = Path.Combine(Directory.GetCurrentDirectory(), "unzip") + "\\";
            Utilerias.directorioZip = Path.Combine(Directory.GetCurrentDirectory(), "zip") + "\\";
            Utilerias.directorioTrabajo = Path.Combine(Directory.GetCurrentDirectory(), "trabajo") + "\\";

            if (!Directory.Exists(Utilerias.directorioUnzip))
                Directory.CreateDirectory(Utilerias.directorioUnzip);

            if (!Directory.Exists(Utilerias.directorioZip))
                Directory.CreateDirectory(Utilerias.directorioZip);
            if (!Directory.Exists(Utilerias.directorioTrabajo))
                Directory.CreateDirectory(Utilerias.directorioTrabajo);

            EliminarArchivos(Utilerias.directorioUnzip);
            EliminarArchivos(Utilerias.directorioZip);
            EliminarArchivos(Utilerias.directorioTrabajo);

            Utilerias.LeeConfiguracion();
            Database.connectionString = $"Data Source={Utilerias.historico}\\archivoHistorico.db;Pooling=true;FailIfMissing=false;";

            this.PopulateLVExpedientes();
        }
        private void menuSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAcercaDe frm = new FrmAcercaDe();
            frm.ShowDialog();
        }
        private void menuExpedientes_Click(object sender, EventArgs e)
        {
            FrmExpedientes frm = new FrmExpedientes();
            frm.ShowDialog();
            PopulateLVExpedientes();
        }
        void PopulateLVExpedientes()
        {
            LVExpedientes.Items.Clear();

            DirectoryInfo pathInfo = new DirectoryInfo(Utilerias.directorio);
            if (!pathInfo.Exists)
            {
                btnFirmar.Enabled = false;
                MessageBox.Show("No existe directorio " + Utilerias.directorio, "Error", MessageBoxButtons.OK);
                return;
            }

            Cursor.Current = Cursors.WaitCursor;
            var expedientesZip = pathInfo.GetFileSystemInfos("*.zip");
            foreach (var expedienteZip in expedientesZip)
            {
                ListViewItem expediente = new ListViewItem(expedienteZip.Name);
                expediente.Tag = expedienteZip.FullName;
                // Se valida expediente
                string anioFolio = DbExpedientes.AnioFolio(expedienteZip.Name);
                if (anioFolio == null)
                {
                    expediente.ForeColor = Color.Red;
                    expediente.SubItems.Add("Error");
                }
                else
                {
                    expediente.Name = anioFolio;
                    int procesado = DbExpedientes.YaProcesado(anioFolio); // -1 no existe, 0=no procesado, 1=procesado
                    if (procesado == -1) // no existe el expediente
                    {
                        expediente.SubItems.Add("Sin Fechas");
                        expediente.ForeColor = Color.Blue;
                    }
                    else if (procesado == 0) // no procesado
                    {
                        expediente.ForeColor = Color.Green; // listo para proceso
                        expediente.SubItems.Add("OK");
                    }
                    else
                        expediente = null; // ya existe y ya esta procesado, nada por hacer
                }
                if (expediente != null)
                    LVExpedientes.Items.Add(expediente);
            }

            if (LVExpedientes.Items.Count > 0)
                LVExpedientes.Items[0].Selected = true;
            else
                btnFirmar.Enabled = false;

            Cursor.Current = Cursors.Default;
        }
        private void LVExpedientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            LVFiles.Items.Clear();
            if (LVExpedientes.SelectedItems.Count == 0)
            {
                btnFirmar.Enabled = false;
                return;
            }
            // Se extraen los archivos del ZIP
            var expedienteZip = LVExpedientes.SelectedItems[0];
            try
            {
                using (ZipArchive archive = ZipFile.OpenRead(expedienteZip.Tag.ToString()))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        ListViewItem archivo = new ListViewItem(entry.Name);
                        LVFiles.Items.Add(archivo);
                    }
                }
            }
            catch (Exception ex)
            {
                expedienteZip.ForeColor = Color.Red;
                MessageBox.Show("ZIP del Expediente dañado. " + Environment.NewLine+ ex.Message, "Error", MessageBoxButtons.OK);
                return;
            }

            if ((expedienteZip.ForeColor == Color.Green))
            {
                string anioFolio = expedienteZip.Name;
                DbExpediente dbExpediente = DbExpedientes.Get(anioFolio);

                txtAnio.Text = dbExpediente.anio;

                txtF_his.Text = DateTime.Now.ToString("dd/MM/yyyy");

                txtFolioEntrega.Text = dbExpediente.folioEntrega;
                txtExpedienteDGAA.Text = dbExpediente.expedienteDGAA;
                txtFechaInicial.Text = Utilerias.FechaDDMMAAAA(dbExpediente.f_ini);
                txtFechaFinal.Text = Utilerias.FechaDDMMAAAA(dbExpediente.f_fin);
                txtExpediente.Text =
                    Utilerias.FondoSeccion + " ," +
                    Utilerias.TipoRequerimiento + $" ,{Utilerias.CambiaPorDGA} , , ," +
                    txtFechaInicial.Text + " ," +
                    txtFechaFinal.Text + " , ," +
                    dbExpediente.expedienteDGAA;

                txtFondoSeccion.Text = Utilerias.FondoSeccion;
                txtResponsable.Text = Utilerias.Responsable;
                txtExpedienteGenerico.Text = Utilerias.ExpedienteGenerico;
                txtTipoDeClasificacion.Text = Utilerias.TipoDeClasificacion;
                txtArchivoDeTramite.Text = Utilerias.ArchivoDeTramite;
                txtValorDocumental.Text = Utilerias.ValorDocumental;
                txtArchivoConcentracion.Text = Utilerias.ArchivoConcentracion;
                txtValorHistorico.Text = Utilerias.ValorHistorico;
                txtTecnicasDeSeleccion.Text = Utilerias.TecnicasDeSeleccion;
                txtCambiaPorDGA.Text = Utilerias.CambiaPorDGA;
                txtPersonaResponsable.Text = Utilerias.PersonaResponsable.Replace(@"\n", Environment.NewLine);

                btnFirmar.Enabled = true;
            }
            else
            {
                txtAnio.Text = "";
                txtF_his.Text = "";
                txtFolioEntrega.Text = "";
                txtExpedienteDGAA.Text = "";
                txtFechaInicial.Text = "";
                txtFechaFinal.Text = "";

                txtFondoSeccion.Text = "";
                txtResponsable.Text = "";
                txtExpedienteGenerico.Text = "";
                txtTipoDeClasificacion.Text = "";
                txtArchivoDeTramite.Text = "";
                txtValorDocumental.Text = "";
                txtArchivoConcentracion.Text = "";
                txtValorHistorico.Text = "";
                txtTecnicasDeSeleccion.Text = "";
                txtExpediente.Text = "";
                txtPersonaResponsable.Text = "";
                txtCambiaPorDGA.Text = "";

                btnFirmar.Enabled = false;
            }
        }
        private void LVFiles_ItemActivate(object sender, EventArgs e)
        {
            if (LVFiles.SelectedItems.Count <= 0)
                return;

            var expediente = LVExpedientes.SelectedItems[0];
            var archivo = LVFiles.SelectedItems[0];

            using (ZipArchive archive = ZipFile.OpenRead(expediente.Tag.ToString()))
            {
                foreach (ZipArchiveEntry entry in archive.Entries)
                {
                    if (entry.Name == archivo.Text)
                    {
                        string destinationPath = Utilerias.directorioUnzip + entry.Name;
                        if (!File.Exists(destinationPath))
                        {
                            try
                            {
                                entry.ExtractToFile(@destinationPath, true);
                                ShellUtilities.Execute(destinationPath);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Archivo:" + entry.Name + " " + ex.Message, "Error al Extraer", MessageBoxButtons.OK);
                            }
                        }
                    }
                }
            }
        }
        private void EliminarArchivos(string directorio)
        {
            DirectoryInfo path = new DirectoryInfo(directorio);
            var archivos = path.GetFileSystemInfos("*.*");
            foreach (var archivo in archivos)
            {
                try
                {
                    File.Delete(archivo.FullName);
                }
                catch { }
            }
        }
        private void BtnFirmar_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            EliminarArchivos(Utilerias.directorioUnzip);
            EliminarArchivos(Utilerias.directorioZip);
            EliminarArchivos(Utilerias.directorioTrabajo);

            try
            {
                // los archivos PDF que forman el expediente
                var expediente = LVExpedientes.SelectedItems[0];
                string anioFolio = expediente.Name;
                int indiceExpedienteSeleccionado = expediente.Index; // para regresar al mismo indice despues de firmar

                List<string> listaTrabajo = new List<string>();
                // En expediente.TAG viene el path completo del archivo zip del expediente
                using (ZipArchive archive = ZipFile.OpenRead(expediente.Tag.ToString()))
                {
                    foreach (ZipArchiveEntry entry in archive.Entries)
                    {
                        string destinationPath = Utilerias.directorioTrabajo + entry.Name;
                        try
                        {
                            entry.ExtractToFile(@destinationPath, true);
                            listaTrabajo.Add(destinationPath);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error al descompactar " + ex.Message, "Error" + entry.Name, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                            return;
                        }
                    }
                }
                listaTrabajo.Sort();

                DbExpediente dbExpediente = DbExpedientes.Get(anioFolio);
                if (! PonerFolio(listaTrabajo, dbExpediente.expedienteDGAA) ) // Crea los archivos PDF con folio y copia los archivos que no son PDF al directorio Zip
                    return;
                // Carátula
                string expedientePDF = expediente.Text.ToLower().Replace(".zip", ".pdf");
                string pathCaratulaPDF = Utilerias.directorioZip + expedientePDF;
                CreaCaratula(pathCaratulaPDF, listaTrabajo); // Crea caratula en directorio Zip
                CreaExpedientePDF(expediente.Text, listaTrabajo, anioFolio);
                string checksum = CalculaCheckSum(Utilerias.directorioZip);
                // Se hace el zip del expediente y se guarda en el sub directorio del año correspondiente
                string pathHistoricoAnio = Path.Combine(Utilerias.historico, dbExpediente.anio);
                // En caso de que el directorio historico del año no exista, se crea.
                if (!Directory.Exists(pathHistoricoAnio))
                    Directory.CreateDirectory(pathHistoricoAnio);
                string pathHistorico = Path.Combine(pathHistoricoAnio, anioFolio + ".zip");
                if (File.Exists(pathHistorico))
                    File.Delete(pathHistorico);
                // Se crea archivo zip histórico
                ZipFile.CreateFromDirectory(Utilerias.directorioZip, pathHistorico);
                // Se obtiene la fecha actual para ponerlo como fecha historico y se marca como expediente procesado
                string f_his = Utilerias.FormatoFecha(txtF_his.Text);
                string mes_his = f_his.Substring(0, 6);
                DbExpedientes.Procesado(anioFolio, checksum, f_his, mes_his);
                // Se renombra al archivo zip del expediente con la extensión .PROCESADO
                string archivoProcesado = expediente.Tag.ToString().ToLower().Replace(".zip", ".PROCESADO");
                Directory.Move(expediente.Tag.ToString(), archivoProcesado);

                if (!cargaMasiva)
                    MessageBox.Show($"Expediente {expediente.Text} procesado ", "Proceso exitoso", MessageBoxButtons.OK);

                // Se selecciona el siguiente expediente
                LVExpedientes.SelectedItems[0].Remove();
                if (LVExpedientes.Items.Count > 0)
                {
                    if (indiceExpedienteSeleccionado < LVExpedientes.Items.Count)
                        LVExpedientes.Items[indiceExpedienteSeleccionado].Selected = true;
                    else
                        if (indiceExpedienteSeleccionado == LVExpedientes.Items.Count)
                        LVExpedientes.Items[LVExpedientes.Items.Count - 1].Selected = true;
                    else
                        LVExpedientes.Items[0].Selected = true;
                }
                else
                {
                    btnFirmar.Enabled = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al firmar: " + ex.Message, "Error", MessageBoxButtons.OK);
                throw new Exception(ex.ToString(), ex);
            }
            Cursor.Current = Cursors.Default;
        }
        private string CalculaCheckSum(string directorio)
        {
            string checksum = "";
            var filePaths = Directory.GetFiles(directorio).OrderBy(f => f);
            foreach (var filename in filePaths)
            {
                string file = Path.GetFileName(filename);
                using (var md5 = MD5.Create())
                {
                    using (var stream = File.OpenRead(filename))
                    {
                        var hash = md5.ComputeHash(stream);
                        checksum += BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                    }
                }
            }
            return checksum;
        }
        private void CreaCaratula(string pathCaratulaPDF, List<string> listaTrabajo)
        {
            int numeroPaginas = NumeroDePaginas(listaTrabajo);
            int numeroPDFs = NumeroDePDFs(listaTrabajo);
            int numeroArchivos = listaTrabajo.Count();

            using (System.IO.FileStream fs = new FileStream(pathCaratulaPDF, FileMode.Create, FileAccess.Write))
            {
                BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, BaseFont.EMBEDDED);
                iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 8);

                iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(Path.Combine(Directory.GetCurrentDirectory(), "Imagenes", "CNBV.jpg"));
                iTextSharp.text.Image firma = iTextSharp.text.Image.GetInstance(Path.Combine(Directory.GetCurrentDirectory(), "Imagenes", "firma.jpg"));

                using (Document document = new Document(PageSize.LETTER, 10f, 10f, 50f, 10f))
                using (PdfWriter writer = PdfWriter.GetInstance(document, fs))
                {
                    document.Open();
                    // Add meta information to the document  
                    document.AddAuthor("DGAA");
                    document.AddCreator("CNBV");
                    document.AddKeywords("Expediente " + txtExpediente.Text);
                    document.AddSubject("Expediente Archivo Histórico");
                    document.AddTitle("Expediente " + txtExpediente.Text);

                    logo.ScaleToFit(125f, 60F);
                    logo.SetAbsolutePosition(50, 700);
                    document.Add(logo);

                    firma.ScaleToFit(125f, 60F);
                    firma.SetAbsolutePosition(220, 350);
                    document.Add(firma);

                    Paragraph pEncabezado = new Paragraph();
                    Phrase phrase = new Phrase();
                    Chunk chunk = new Chunk(Chunk.NEWLINE + "Expediente");
                    phrase.Add(chunk);
                    pEncabezado.Add(phrase);
                    pEncabezado.SpacingAfter = 25f;
                    pEncabezado.Alignment = Element.ALIGN_CENTER;
                    document.Add(pEncabezado);

                    PdfPTable table = new PdfPTable(8);
                    table.DefaultCell.Phrase = new Phrase() { Font = font };

                    Renglon1Col(table, "Fondo Sección:", txtFondoSeccion.Text);
                    Renglon1Col(table, "Responsable:", txtResponsable.Text);

                    Renglon(table, " ");
                    Renglon1Col(table, "Expediente Genérico (Serie):", txtExpedienteGenerico.Text);

                    Renglon(table, " ");
                    Renglon2Cols(table, "Tipo Clasificación", txtTipoDeClasificacion.Text, "Archivo Trámite:", txtArchivoDeTramite.Text);
                    Renglon2Cols(table, "Valor Documental:", txtValorDocumental.Text, "Archivo Concentración:", txtArchivoConcentracion.Text);
                    Renglon2Cols(table, "Valor Histórico:", txtValorHistorico.Text, "Técnicas de Selección:", txtTecnicasDeSeleccion.Text);

                    Renglon(table, " ");
                    Renglon1Col(table, "Fecha Inicial:", txtFechaInicial.Text);
                    Renglon1Col(table, "Fecha Final:", txtFechaFinal.Text);
                    Renglon1Col(table, "Número de Archivos", numeroArchivos.ToString("D6") + " más la carátula");
                    Renglon1Col(table, "Número de Archivos PDF", $"{numeroPDFs.ToString("D6")} archivos PDF con {numeroPaginas.ToString("D6")} páginas foliadas");

                    Renglon(table, " ");
                    Renglon1Col(table, "Expediente", txtExpediente.Text);
                    Renglon(table, " ");
                    Renglon1Col(table, "Responsable(s)", txtPersonaResponsable.Text);
                    Renglon(table, " ");
                    Renglon1Col(table, "Firmas(s) Responsable(s)", " ");

                    document.Add(table);

                    document.Add(new Chunk("\n"));
                    document.Add(new Chunk("\n"));
                    document.Add(new Chunk("\n"));

                    PdfPTable tableDocs = new PdfPTable(1);
                    tableDocs.DefaultCell.Phrase = new Phrase() { Font = font };
                    PdfPCell cell = new PdfPCell(new Phrase("Documentos archivados", font));
                    cell.Colspan = 1;
                    cell.HorizontalAlignment = 1;
                    tableDocs.AddCell(cell);

                    for (int f = 0; f < listaTrabajo.Count; f++)
                    {
                        string sourceFile = Path.GetFileName(listaTrabajo[f]);
                        string extension = Path.GetExtension(sourceFile);

                        PdfPCell cellDocumentos = new PdfPCell(new Phrase(sourceFile, font));
                        tableDocs.AddCell(cellDocumentos);
                    }
                    document.Add(tableDocs);

                    document.Close();
                    writer.Close();
                    fs.Close();
                }
            }
        }
        private void Renglon(PdfPTable table, string lbl)
        {
            PdfPCell cellRenglon = new PdfPCell(new Phrase(lbl));
            cellRenglon.BorderColor = BaseColor.WHITE;
            cellRenglon.Colspan = 8;
            cellRenglon.HorizontalAlignment = 1;
            table.AddCell(cellRenglon);
        }
        private void Renglon1Col(PdfPTable table, string lbl, string txt)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, BaseFont.EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 8);

            PdfPCell etiqueta = new PdfPCell(new Phrase(lbl, font));
            etiqueta.BorderColor = BaseColor.WHITE;
            etiqueta.Colspan = 3;
            etiqueta.HorizontalAlignment = 0; //0=Left, 1=Centre, 2=Right
            table.AddCell(etiqueta);

            PdfPCell texto = new PdfPCell(new Phrase(txt, font));
            texto.BorderColor = BaseColor.WHITE;
            texto.Colspan = 5;
            texto.HorizontalAlignment = 0;
            table.AddCell(texto);

        }
        private void Renglon2Cols(PdfPTable table, string lbl1, string txt1, string lbl2, string txt2)
        {
            BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, BaseFont.EMBEDDED);
            iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 8);

            PdfPCell etiqueta1 = new PdfPCell(new Phrase(lbl1, font));
            etiqueta1.BorderColor = BaseColor.WHITE;
            etiqueta1.Colspan = 2;
            etiqueta1.HorizontalAlignment = 0;
            table.AddCell(etiqueta1);

            PdfPCell texto1 = new PdfPCell(new Phrase(txt1, font));
            texto1.BorderColor = BaseColor.WHITE;
            texto1.Colspan = 2;
            texto1.HorizontalAlignment = 0;
            table.AddCell(texto1);

            PdfPCell etiqueta2 = new PdfPCell(new Phrase(lbl2, font));
            etiqueta2.BorderColor = BaseColor.WHITE;
            etiqueta2.Colspan = 2;
            etiqueta2.HorizontalAlignment = 0;
            table.AddCell(etiqueta2);

            PdfPCell texto2 = new PdfPCell(new Phrase(txt2, font));
            texto2.BorderColor = BaseColor.WHITE;
            texto2.Colspan = 2;
            texto2.HorizontalAlignment = 0;
            table.AddCell(texto2);

        }
        private int NumeroDePaginas(List<string> sourceFiles)
        {
            int n = 0;
            try
            {
                for (int f = 0; f < sourceFiles.Count; f++)
                {
                    string sourceFile = Path.GetFileName(sourceFiles[f]);
                    string extension = Path.GetExtension(sourceFile);

                    if (extension.ToLower() == ".pdf")
                    {
                        PdfReader reader = new PdfReader(sourceFiles[f]);
                        n += reader.NumberOfPages;
                    }
                }
            }
            catch (Exception e)
            {
                MessageBox.Show("Error al leer archivos PDF. " + e.Message, "Error");
                n = 0;
            }
            return n;
        }
        private int NumeroDePDFs(List<string> sourceFiles)
        {
            int n = 0;
            for (int f = 0; f < sourceFiles.Count; f++)
            {
                string sourceFile = Path.GetFileName(sourceFiles[f]);
                string extension = Path.GetExtension(sourceFile);

                if (extension.ToLower() == ".pdf")
                {
                    n += 1;
                }
            }
            return n;
        }
        private bool PonerFolio(List<string> listaTrabajo, string expediente)
        {
            string archivoPDF=""; // se usa para reportar error en su caso.
            try
            {
                int folio = 0;
                var baseFont = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

                for (int f = 0; f < listaTrabajo.Count; f++)
                {
                    string sourceFile = Path.GetFileName(listaTrabajo[f]);
                    string extension = Path.GetExtension(sourceFile);
                    string destinationFile = Utilerias.directorioZip + sourceFile;

                    if (extension.ToLower() != ".pdf")
                    {
                        // Cuando el archivo NO es pdf entonces solo se copia
                        File.Copy(listaTrabajo[f], destinationFile, true);
                    }
                    else
                    {
                        archivoPDF = listaTrabajo[f];
                        using (PdfReader reader = new PdfReader(listaTrabajo[f]))
                        using (Document document = new Document(PageSize.LETTER))
                        using (PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(destinationFile, FileMode.Create, FileAccess.Write)))
                        {
                            document.Open();

                            int n = reader.NumberOfPages;

                            for (int i = 1; i <= n; i++)
                            {
                                document.NewPage();

                                PdfImportedPage page = writer.GetImportedPage(reader, i);
                                PdfContentByte cb = writer.DirectContent;

                                int rotation = reader.GetPageRotation(i);
                                if (rotation == 90 || rotation == 270)
                                {
                                    cb.AddTemplate(page, 0, -1f, 1f, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                                }
                                else
                                {
                                    // cb.AddTemplate(page, 1f, 0, 0, 1f, 0, 0);
                                    cb.AddTemplate(page, PageSize.LETTER.Width / reader.GetPageSize(i).Width, 0, 0,
                                                         PageSize.LETTER.Height / reader.GetPageSize(i).Height, 0, 0);
                                }
                                folio++;
                                cb.BeginText();
                                cb.SetFontAndSize(baseFont, 12);
                                cb.SetColorFill(BaseColor.RED);
                                cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, folio.ToString("D8") + " -> " + expediente, 0, 0, 0);
                                cb.EndText();
                            }
                            document.Close();
                            reader.Close();
                        }
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error en archivo PDF {archivoPDF}. {Environment.NewLine}El archivo de salida puede estar abierto, cierrelo. " + e.Message, "Error al escribir");
                return false;
            }
        }
        private void consultaMenu_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("ConsultaHistorico.exe");
        }
        private void sacarHistórico_Click(object sender, EventArgs e)
        {
            FrmSacarHistorico frm = new FrmSacarHistorico();
            frm.ShowDialog();
            PopulateLVExpedientes();
        }
        private bool CreaExpedientePDF(string expediente, List<string> fileNames, string folioEntrega)
        {
            string destinationFile = Path.Combine(Utilerias.directorioZip, "_" + folioEntrega + ".pdf");
            string expedientePDF = expediente.ToLower().Replace(".zip", ".pdf");
            string pathCaratulaPDF = Utilerias.directorioZip + expedientePDF;

            List<string> lista = new List<string>();
            lista.Add(pathCaratulaPDF);
            foreach (string file in fileNames)
                lista.Add(file);

            bool merged = true;
            using (FileStream stream = new FileStream(destinationFile, FileMode.Create))
            {
                using (Document document = new Document())
                {
                    PdfCopy pdf = new PdfCopy(document, stream);
                    try
                    {
                        document.Open();
                        foreach (string file in lista)
                        {
                            string sourceFile = Path.GetFileName(file);
                            string extension = Path.GetExtension(sourceFile);

                            if (extension.ToLower() == ".pdf")
                            {
                                string sourceFileFoliado = Utilerias.directorioZip + sourceFile;
                                using (var reader = new PdfReader(sourceFileFoliado))
                                {
                                    pdf.AddDocument(reader);
                                    reader.Close();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        merged = false;
                    }
                    finally
                    {
                        if (document != null)
                        {
                            document.Close();
                        }
                    }
                }
                stream.Close();
            }
            return merged;
        }
        private void btnCargaMasiva_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Se hará carga masiva de los expedientes en verde. ¿Está de acuerdo?", "Carga Masiva", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                cargaMasiva = true;
                while (LVExpedientes.Items.Count > 0)
                {
                    BtnFirmar_Click(null, null);
                }
                cargaMasiva = false;
            }
        }
        private void FrmMain_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control)
                sacarHistóricoToolStripMenuItem.Visible = true;

            if (e.KeyCode == Keys.C && e.Control)
                consultaToolStripMenuItem.Visible = true;
        }

        private void reporteMenu_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show("¿Generar el archivo Reporte.csv?", "Confirme", MessageBoxButtons.YesNo);
            if (dialogResult == DialogResult.Yes)
            {
                string reporte = Path.Combine(Directory.GetCurrentDirectory(), "reporte.csv");
                DbExpedientes.Reporte(reporte);
                MessageBox.Show($"Archivo Generado {reporte}", "Reporte", MessageBoxButtons.OK);
            }
        }

        private void informaciónBDMenu_Click(object sender, EventArgs e)
        {
            FrmInformacionBD frm = new FrmInformacionBD();
            frm.ShowDialog();
        }
    }
}
