﻿using System;
using System.Data.SQLite;
using System.Windows.Forms;
using Utilities;

namespace ArchivoHistorico
{
    partial class FrmInformacionBD: Form
    {
        public FrmInformacionBD()
        {
            InitializeComponent();
        }

        private void FrmTrazabilidad_Load(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            LVInformacion.Items.Clear();
            LVInformacion.Items.Add("Información por año de expediente:");
            string sql = "SELECT anio, COUNT(folioEntrega) as cuenta FROM Expedientes GROUP BY anio";
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    string s = "";
                    s += "Año: " + reader[0].ToString();
                    s += " -> " + reader[1].ToString() + " expedientes";
                    LVInformacion.Items.Add(s);
                }
            }
            LVInformacion.Items.Add("Información por mes de registro en archivo histórico:");
            sql = "SELECT mes_his, COUNT(folioEntrega) as cuenta FROM Expedientes GROUP BY mes_his";
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                while (reader.Read())
                {
                    string s = "";
                    s += "Mes: " + reader[0].ToString();
                    s += " -> " + reader[1].ToString() + " expedientes";
                    LVInformacion.Items.Add(s);
                }
            }
            Cursor.Current = Cursors.Default;
        }

        private void BtnPortapapeles_Click(object sender, EventArgs e)
        {
            string s = "";
            foreach (ListViewItem item in LVInformacion.Items)
            {
                s += item.Text.ToString() + Environment.NewLine;
            }
            Clipboard.SetText(s);
        }
    }
}
