﻿namespace ArchivoHistorico
{
    partial class FrmInformacionBD
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.LVInformacion = new System.Windows.Forms.ListView();
            this.BtnPortapapeles = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancelar.Location = new System.Drawing.Point(314, 321);
            this.BtnCancelar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(69, 24);
            this.BtnCancelar.TabIndex = 31;
            this.BtnCancelar.Text = "Regresar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            // 
            // LVInformacion
            // 
            this.LVInformacion.HideSelection = false;
            this.LVInformacion.Location = new System.Drawing.Point(11, 8);
            this.LVInformacion.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LVInformacion.Name = "LVInformacion";
            this.LVInformacion.Size = new System.Drawing.Size(560, 295);
            this.LVInformacion.TabIndex = 32;
            this.LVInformacion.UseCompatibleStateImageBehavior = false;
            this.LVInformacion.View = System.Windows.Forms.View.List;
            // 
            // BtnPortapapeles
            // 
            this.BtnPortapapeles.Location = new System.Drawing.Point(171, 321);
            this.BtnPortapapeles.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnPortapapeles.Name = "BtnPortapapeles";
            this.BtnPortapapeles.Size = new System.Drawing.Size(82, 24);
            this.BtnPortapapeles.TabIndex = 35;
            this.BtnPortapapeles.Text = "Portapapeles";
            this.BtnPortapapeles.UseVisualStyleBackColor = true;
            this.BtnPortapapeles.Click += new System.EventHandler(this.BtnPortapapeles_Click);
            // 
            // FrmInformacionBD
            // 
            this.AcceptButton = this.BtnCancelar;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(582, 364);
            this.Controls.Add(this.BtnPortapapeles);
            this.Controls.Add(this.LVInformacion);
            this.Controls.Add(this.BtnCancelar);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmInformacionBD";
            this.Padding = new System.Windows.Forms.Padding(9, 9, 9, 9);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Información Base de Datos";
            this.Load += new System.EventHandler(this.FrmTrazabilidad_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.ListView LVInformacion;
        private System.Windows.Forms.Button BtnPortapapeles;
    }
}
