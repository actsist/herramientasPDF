﻿namespace ArchivoHistorico
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.reporteMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.informaciónBDMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.consultaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sacarHistóricoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menu1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.btnCargaMasiva = new System.Windows.Forms.Button();
            this.txtAnio = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.txtF_his = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.txtCambiaPorDGA = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtFolioEntrega = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.txtExpedienteDGAA = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtFechaInicial = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtFechaFinal = new System.Windows.Forms.TextBox();
            this.txtPersonaResponsable = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.txtExpedienteGenerico = new System.Windows.Forms.TextBox();
            this.picFirma = new System.Windows.Forms.PictureBox();
            this.txtResponsable = new System.Windows.Forms.TextBox();
            this.txtExpediente = new System.Windows.Forms.TextBox();
            this.txtFondoSeccion = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtTecnicasDeSeleccion = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtValorHistorico = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtArchivoConcentracion = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtValorDocumental = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtArchivoDeTramite = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtTipoDeClasificacion = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btnFirmar = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.LVFiles = new System.Windows.Forms.ListView();
            this.ColArchivos = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel6 = new System.Windows.Forms.Panel();
            this.LVExpedientes = new System.Windows.Forms.ListView();
            this.colExpedientes = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.colStatus = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.menuStrip1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFirma)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(28, 28);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem4,
            this.reporteMenu,
            this.informaciónBDMenu,
            this.consultaToolStripMenuItem,
            this.sacarHistóricoToolStripMenuItem,
            this.acercaDeToolStripMenuItem,
            this.menu1ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(7, 4, 0, 4);
            this.menuStrip1.Size = new System.Drawing.Size(2059, 42);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(142, 34);
            this.toolStripMenuItem4.Text = "Expedientes";
            this.toolStripMenuItem4.Click += new System.EventHandler(this.menuExpedientes_Click);
            // 
            // reporteMenu
            // 
            this.reporteMenu.Name = "reporteMenu";
            this.reporteMenu.Size = new System.Drawing.Size(103, 34);
            this.reporteMenu.Text = "Reporte";
            this.reporteMenu.Click += new System.EventHandler(this.reporteMenu_Click);
            // 
            // informaciónBDMenu
            // 
            this.informaciónBDMenu.Name = "informaciónBDMenu";
            this.informaciónBDMenu.Size = new System.Drawing.Size(170, 34);
            this.informaciónBDMenu.Text = "InformaciónBD";
            this.informaciónBDMenu.Click += new System.EventHandler(this.informaciónBDMenu_Click);
            // 
            // consultaToolStripMenuItem
            // 
            this.consultaToolStripMenuItem.Name = "consultaToolStripMenuItem";
            this.consultaToolStripMenuItem.Size = new System.Drawing.Size(112, 34);
            this.consultaToolStripMenuItem.Text = "Consulta";
            this.consultaToolStripMenuItem.Visible = false;
            this.consultaToolStripMenuItem.Click += new System.EventHandler(this.consultaMenu_Click);
            // 
            // sacarHistóricoToolStripMenuItem
            // 
            this.sacarHistóricoToolStripMenuItem.Name = "sacarHistóricoToolStripMenuItem";
            this.sacarHistóricoToolStripMenuItem.Size = new System.Drawing.Size(189, 34);
            this.sacarHistóricoToolStripMenuItem.Text = "SacarDeHistórico";
            this.sacarHistóricoToolStripMenuItem.Visible = false;
            this.sacarHistóricoToolStripMenuItem.Click += new System.EventHandler(this.sacarHistórico_Click);
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(123, 34);
            this.acercaDeToolStripMenuItem.Text = "Acerca de";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // menu1ToolStripMenuItem
            // 
            this.menu1ToolStripMenuItem.Name = "menu1ToolStripMenuItem";
            this.menu1ToolStripMenuItem.Size = new System.Drawing.Size(70, 34);
            this.menu1ToolStripMenuItem.Text = "Salir";
            this.menu1ToolStripMenuItem.Click += new System.EventHandler(this.menuSalir_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 42);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(2059, 1126);
            this.panel2.TabIndex = 7;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.panel7);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(840, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1219, 1126);
            this.panel4.TabIndex = 2;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.btnCargaMasiva);
            this.panel7.Controls.Add(this.txtAnio);
            this.panel7.Controls.Add(this.label19);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Controls.Add(this.txtCambiaPorDGA);
            this.panel7.Controls.Add(this.label4);
            this.panel7.Controls.Add(this.panel1);
            this.panel7.Controls.Add(this.txtPersonaResponsable);
            this.panel7.Controls.Add(this.label1);
            this.panel7.Controls.Add(this.label18);
            this.panel7.Controls.Add(this.txtExpedienteGenerico);
            this.panel7.Controls.Add(this.picFirma);
            this.panel7.Controls.Add(this.txtResponsable);
            this.panel7.Controls.Add(this.txtExpediente);
            this.panel7.Controls.Add(this.txtFondoSeccion);
            this.panel7.Controls.Add(this.label16);
            this.panel7.Controls.Add(this.txtTecnicasDeSeleccion);
            this.panel7.Controls.Add(this.label14);
            this.panel7.Controls.Add(this.txtValorHistorico);
            this.panel7.Controls.Add(this.label13);
            this.panel7.Controls.Add(this.txtArchivoConcentracion);
            this.panel7.Controls.Add(this.label12);
            this.panel7.Controls.Add(this.txtValorDocumental);
            this.panel7.Controls.Add(this.label11);
            this.panel7.Controls.Add(this.txtArchivoDeTramite);
            this.panel7.Controls.Add(this.label10);
            this.panel7.Controls.Add(this.txtTipoDeClasificacion);
            this.panel7.Controls.Add(this.label9);
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this.label6);
            this.panel7.Controls.Add(this.label7);
            this.panel7.Controls.Add(this.btnFirmar);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1219, 1126);
            this.panel7.TabIndex = 8;
            // 
            // btnCargaMasiva
            // 
            this.btnCargaMasiva.Location = new System.Drawing.Point(928, 1052);
            this.btnCargaMasiva.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCargaMasiva.Name = "btnCargaMasiva";
            this.btnCargaMasiva.Size = new System.Drawing.Size(200, 57);
            this.btnCargaMasiva.TabIndex = 46;
            this.btnCargaMasiva.Text = "Carga Masiva";
            this.btnCargaMasiva.UseVisualStyleBackColor = true;
            this.btnCargaMasiva.Visible = false;
            this.btnCargaMasiva.Click += new System.EventHandler(this.btnCargaMasiva_Click);
            // 
            // txtAnio
            // 
            this.txtAnio.Location = new System.Drawing.Point(343, 109);
            this.txtAnio.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAnio.Name = "txtAnio";
            this.txtAnio.ReadOnly = true;
            this.txtAnio.Size = new System.Drawing.Size(142, 29);
            this.txtAnio.TabIndex = 45;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(59, 102);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(54, 25);
            this.label19.TabIndex = 42;
            this.label19.Text = "Año:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.panel8.Controls.Add(this.txtF_his);
            this.panel8.Controls.Add(this.label17);
            this.panel8.Location = new System.Drawing.Point(28, 4);
            this.panel8.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(688, 59);
            this.panel8.TabIndex = 40;
            // 
            // txtF_his
            // 
            this.txtF_his.Location = new System.Drawing.Point(314, 17);
            this.txtF_his.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtF_his.Name = "txtF_his";
            this.txtF_his.ReadOnly = true;
            this.txtF_his.Size = new System.Drawing.Size(296, 29);
            this.txtF_his.TabIndex = 39;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(22, 20);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(192, 25);
            this.label17.TabIndex = 38;
            this.label17.Text = "Fecha Alta Histórico:";
            // 
            // txtCambiaPorDGA
            // 
            this.txtCambiaPorDGA.Location = new System.Drawing.Point(343, 473);
            this.txtCambiaPorDGA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCambiaPorDGA.Name = "txtCambiaPorDGA";
            this.txtCambiaPorDGA.ReadOnly = true;
            this.txtCambiaPorDGA.Size = new System.Drawing.Size(296, 29);
            this.txtCambiaPorDGA.TabIndex = 37;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 473);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 25);
            this.label4.TabIndex = 36;
            this.label4.Text = "Cambia por DGA:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.Info;
            this.panel1.Controls.Add(this.txtFolioEntrega);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.txtExpedienteDGAA);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.txtFechaInicial);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtFechaFinal);
            this.panel1.Location = new System.Drawing.Point(20, 522);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(728, 199);
            this.panel1.TabIndex = 35;
            // 
            // txtFolioEntrega
            // 
            this.txtFolioEntrega.Location = new System.Drawing.Point(323, 13);
            this.txtFolioEntrega.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFolioEntrega.Name = "txtFolioEntrega";
            this.txtFolioEntrega.ReadOnly = true;
            this.txtFolioEntrega.Size = new System.Drawing.Size(296, 29);
            this.txtFolioEntrega.TabIndex = 38;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(39, 17);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(133, 25);
            this.label3.TabIndex = 37;
            this.label3.Text = "Folio Entrega:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 57);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(178, 25);
            this.label8.TabIndex = 35;
            this.label8.Text = "Expediente DGAA:";
            // 
            // txtExpedienteDGAA
            // 
            this.txtExpedienteDGAA.Location = new System.Drawing.Point(323, 57);
            this.txtExpedienteDGAA.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpedienteDGAA.Name = "txtExpedienteDGAA";
            this.txtExpedienteDGAA.ReadOnly = true;
            this.txtExpedienteDGAA.Size = new System.Drawing.Size(387, 29);
            this.txtExpedienteDGAA.TabIndex = 36;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(39, 102);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(127, 25);
            this.label15.TabIndex = 20;
            this.label15.Text = "Fecha Inicial:";
            // 
            // txtFechaInicial
            // 
            this.txtFechaInicial.Location = new System.Drawing.Point(323, 100);
            this.txtFechaInicial.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFechaInicial.Name = "txtFechaInicial";
            this.txtFechaInicial.ReadOnly = true;
            this.txtFechaInicial.Size = new System.Drawing.Size(296, 29);
            this.txtFechaInicial.TabIndex = 21;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 148);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(120, 25);
            this.label2.TabIndex = 30;
            this.label2.Text = "Fecha Final:";
            // 
            // txtFechaFinal
            // 
            this.txtFechaFinal.Location = new System.Drawing.Point(323, 142);
            this.txtFechaFinal.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFechaFinal.Name = "txtFechaFinal";
            this.txtFechaFinal.ReadOnly = true;
            this.txtFechaFinal.Size = new System.Drawing.Size(296, 29);
            this.txtFechaFinal.TabIndex = 31;
            // 
            // txtPersonaResponsable
            // 
            this.txtPersonaResponsable.AcceptsReturn = true;
            this.txtPersonaResponsable.Location = new System.Drawing.Point(343, 822);
            this.txtPersonaResponsable.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPersonaResponsable.Multiline = true;
            this.txtPersonaResponsable.Name = "txtPersonaResponsable";
            this.txtPersonaResponsable.ReadOnly = true;
            this.txtPersonaResponsable.Size = new System.Drawing.Size(846, 80);
            this.txtPersonaResponsable.TabIndex = 29;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(50, 823);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 25);
            this.label1.TabIndex = 28;
            this.label1.Text = "Responsable(s):";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(50, 930);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 25);
            this.label18.TabIndex = 27;
            this.label18.Text = "Firma:";
            // 
            // txtExpedienteGenerico
            // 
            this.txtExpedienteGenerico.Location = new System.Drawing.Point(343, 227);
            this.txtExpedienteGenerico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpedienteGenerico.Name = "txtExpedienteGenerico";
            this.txtExpedienteGenerico.ReadOnly = true;
            this.txtExpedienteGenerico.Size = new System.Drawing.Size(296, 29);
            this.txtExpedienteGenerico.TabIndex = 7;
            // 
            // picFirma
            // 
            this.picFirma.Image = ((System.Drawing.Image)(resources.GetObject("picFirma.Image")));
            this.picFirma.Location = new System.Drawing.Point(343, 930);
            this.picFirma.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.picFirma.Name = "picFirma";
            this.picFirma.Size = new System.Drawing.Size(312, 94);
            this.picFirma.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picFirma.TabIndex = 26;
            this.picFirma.TabStop = false;
            // 
            // txtResponsable
            // 
            this.txtResponsable.Location = new System.Drawing.Point(343, 192);
            this.txtResponsable.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtResponsable.Name = "txtResponsable";
            this.txtResponsable.ReadOnly = true;
            this.txtResponsable.Size = new System.Drawing.Size(679, 29);
            this.txtResponsable.TabIndex = 5;
            // 
            // txtExpediente
            // 
            this.txtExpediente.Location = new System.Drawing.Point(343, 733);
            this.txtExpediente.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpediente.Multiline = true;
            this.txtExpediente.Name = "txtExpediente";
            this.txtExpediente.ReadOnly = true;
            this.txtExpediente.Size = new System.Drawing.Size(846, 69);
            this.txtExpediente.TabIndex = 23;
            // 
            // txtFondoSeccion
            // 
            this.txtFondoSeccion.Location = new System.Drawing.Point(343, 157);
            this.txtFondoSeccion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtFondoSeccion.Name = "txtFondoSeccion";
            this.txtFondoSeccion.ReadOnly = true;
            this.txtFondoSeccion.Size = new System.Drawing.Size(142, 29);
            this.txtFondoSeccion.TabIndex = 3;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(50, 733);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(116, 25);
            this.label16.TabIndex = 22;
            this.label16.Text = "Expediente:";
            // 
            // txtTecnicasDeSeleccion
            // 
            this.txtTecnicasDeSeleccion.Location = new System.Drawing.Point(343, 438);
            this.txtTecnicasDeSeleccion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTecnicasDeSeleccion.Name = "txtTecnicasDeSeleccion";
            this.txtTecnicasDeSeleccion.ReadOnly = true;
            this.txtTecnicasDeSeleccion.Size = new System.Drawing.Size(296, 29);
            this.txtTecnicasDeSeleccion.TabIndex = 19;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(57, 438);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(216, 25);
            this.label14.TabIndex = 18;
            this.label14.Text = "Técnicas de Selección:";
            // 
            // txtValorHistorico
            // 
            this.txtValorHistorico.Location = new System.Drawing.Point(343, 402);
            this.txtValorHistorico.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorHistorico.Name = "txtValorHistorico";
            this.txtValorHistorico.ReadOnly = true;
            this.txtValorHistorico.Size = new System.Drawing.Size(296, 29);
            this.txtValorHistorico.TabIndex = 17;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(57, 406);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(138, 25);
            this.label13.TabIndex = 16;
            this.label13.Text = "Valor Histórico";
            // 
            // txtArchivoConcentracion
            // 
            this.txtArchivoConcentracion.Location = new System.Drawing.Point(343, 367);
            this.txtArchivoConcentracion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtArchivoConcentracion.Name = "txtArchivoConcentracion";
            this.txtArchivoConcentracion.ReadOnly = true;
            this.txtArchivoConcentracion.Size = new System.Drawing.Size(296, 29);
            this.txtArchivoConcentracion.TabIndex = 15;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(57, 371);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(216, 25);
            this.label12.TabIndex = 14;
            this.label12.Text = "Archivo Concentración:";
            // 
            // txtValorDocumental
            // 
            this.txtValorDocumental.Location = new System.Drawing.Point(343, 332);
            this.txtValorDocumental.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtValorDocumental.Name = "txtValorDocumental";
            this.txtValorDocumental.ReadOnly = true;
            this.txtValorDocumental.Size = new System.Drawing.Size(296, 29);
            this.txtValorDocumental.TabIndex = 13;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(57, 336);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(173, 25);
            this.label11.TabIndex = 12;
            this.label11.Text = "Valor Documental:";
            // 
            // txtArchivoDeTramite
            // 
            this.txtArchivoDeTramite.Location = new System.Drawing.Point(343, 297);
            this.txtArchivoDeTramite.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtArchivoDeTramite.Name = "txtArchivoDeTramite";
            this.txtArchivoDeTramite.ReadOnly = true;
            this.txtArchivoDeTramite.Size = new System.Drawing.Size(296, 29);
            this.txtArchivoDeTramite.TabIndex = 11;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(57, 303);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(182, 25);
            this.label10.TabIndex = 10;
            this.label10.Text = "Archivo de Trámite:";
            // 
            // txtTipoDeClasificacion
            // 
            this.txtTipoDeClasificacion.Location = new System.Drawing.Point(343, 262);
            this.txtTipoDeClasificacion.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTipoDeClasificacion.Name = "txtTipoDeClasificacion";
            this.txtTipoDeClasificacion.ReadOnly = true;
            this.txtTipoDeClasificacion.Size = new System.Drawing.Size(296, 29);
            this.txtTipoDeClasificacion.TabIndex = 9;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(57, 268);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(199, 25);
            this.label9.TabIndex = 8;
            this.label9.Text = "Tipo de Clasificación:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(57, 233);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(261, 25);
            this.label5.TabIndex = 6;
            this.label5.Text = "Expediente Genérico (serie):";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(57, 192);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(132, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "Responsable:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(57, 157);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(150, 25);
            this.label7.TabIndex = 2;
            this.label7.Text = "Fondo Sección:";
            // 
            // btnFirmar
            // 
            this.btnFirmar.Location = new System.Drawing.Point(343, 1058);
            this.btnFirmar.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnFirmar.Name = "btnFirmar";
            this.btnFirmar.Size = new System.Drawing.Size(372, 52);
            this.btnFirmar.TabIndex = 0;
            this.btnFirmar.Text = "Firmar y Pasar a Archivo Histórico";
            this.btnFirmar.UseVisualStyleBackColor = true;
            this.btnFirmar.Click += new System.EventHandler(this.BtnFirmar_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel6);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(840, 1126);
            this.panel3.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.LVFiles);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(0, 558);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(840, 568);
            this.panel5.TabIndex = 3;
            // 
            // LVFiles
            // 
            this.LVFiles.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.ColArchivos});
            this.LVFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LVFiles.Font = new System.Drawing.Font("Courier New", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVFiles.FullRowSelect = true;
            this.LVFiles.HideSelection = false;
            this.LVFiles.Location = new System.Drawing.Point(0, 0);
            this.LVFiles.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.LVFiles.MultiSelect = false;
            this.LVFiles.Name = "LVFiles";
            this.LVFiles.ShowGroups = false;
            this.LVFiles.Size = new System.Drawing.Size(840, 568);
            this.LVFiles.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.LVFiles.TabIndex = 3;
            this.LVFiles.UseCompatibleStateImageBehavior = false;
            this.LVFiles.View = System.Windows.Forms.View.Details;
            this.LVFiles.ItemActivate += new System.EventHandler(this.LVFiles_ItemActivate);
            // 
            // ColArchivos
            // 
            this.ColArchivos.Text = "ARCHIVOS";
            this.ColArchivos.Width = 450;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.LVExpedientes);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel6.Location = new System.Drawing.Point(0, 0);
            this.panel6.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(840, 558);
            this.panel6.TabIndex = 2;
            // 
            // LVExpedientes
            // 
            this.LVExpedientes.BackColor = System.Drawing.SystemColors.Window;
            this.LVExpedientes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colExpedientes,
            this.colStatus});
            this.LVExpedientes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.LVExpedientes.Font = new System.Drawing.Font("Courier New", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVExpedientes.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LVExpedientes.HideSelection = false;
            this.LVExpedientes.Location = new System.Drawing.Point(0, 0);
            this.LVExpedientes.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.LVExpedientes.MultiSelect = false;
            this.LVExpedientes.Name = "LVExpedientes";
            this.LVExpedientes.ShowGroups = false;
            this.LVExpedientes.Size = new System.Drawing.Size(840, 558);
            this.LVExpedientes.TabIndex = 0;
            this.LVExpedientes.UseCompatibleStateImageBehavior = false;
            this.LVExpedientes.View = System.Windows.Forms.View.Details;
            this.LVExpedientes.SelectedIndexChanged += new System.EventHandler(this.LVExpedientes_SelectedIndexChanged);
            // 
            // colExpedientes
            // 
            this.colExpedientes.Text = "EXPEDIENTES";
            this.colExpedientes.Width = 350;
            // 
            // colStatus
            // 
            this.colStatus.Text = "Status";
            this.colStatus.Width = 100;
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2059, 1168);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Archivo Histórico";
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FrmMain_KeyDown);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFirma)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem menu1ToolStripMenuItem;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.TextBox txtFechaFinal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtPersonaResponsable;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtExpedienteGenerico;
        private System.Windows.Forms.PictureBox picFirma;
        private System.Windows.Forms.TextBox txtResponsable;
        private System.Windows.Forms.TextBox txtExpediente;
        private System.Windows.Forms.TextBox txtFondoSeccion;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtFechaInicial;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtTecnicasDeSeleccion;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txtValorHistorico;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtArchivoConcentracion;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtValorDocumental;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtArchivoDeTramite;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtTipoDeClasificacion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnFirmar;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.ListView LVFiles;
        private System.Windows.Forms.ColumnHeader ColArchivos;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ListView LVExpedientes;
        private System.Windows.Forms.ColumnHeader colExpedientes;
        private System.Windows.Forms.ColumnHeader colStatus;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox txtCambiaPorDGA;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtExpedienteDGAA;
        private System.Windows.Forms.ToolStripMenuItem consultaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sacarHistóricoToolStripMenuItem;
        private System.Windows.Forms.TextBox txtFolioEntrega;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txtF_his;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtAnio;
        private System.Windows.Forms.Button btnCargaMasiva;
        private System.Windows.Forms.ToolStripMenuItem reporteMenu;
        private System.Windows.Forms.ToolStripMenuItem informaciónBDMenu;
    }
}

