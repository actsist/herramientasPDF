﻿namespace ArchivoHistorico
{
    partial class FrmExpedientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmExpedientes));
            this.LblAviso = new System.Windows.Forms.Label();
            this.BtnActualizar = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.LVExpedientes = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // LblAviso
            // 
            this.LblAviso.AutoSize = true;
            this.LblAviso.Location = new System.Drawing.Point(7, 12);
            this.LblAviso.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.LblAviso.Name = "LblAviso";
            this.LblAviso.Size = new System.Drawing.Size(222, 13);
            this.LblAviso.TabIndex = 27;
            this.LblAviso.Text = "Se lee la base de datos _EXPEDIENTES.csv";
            // 
            // BtnActualizar
            // 
            this.BtnActualizar.Location = new System.Drawing.Point(159, 274);
            this.BtnActualizar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnActualizar.Name = "BtnActualizar";
            this.BtnActualizar.Size = new System.Drawing.Size(69, 24);
            this.BtnActualizar.TabIndex = 29;
            this.BtnActualizar.Text = "Actualizar";
            this.BtnActualizar.UseVisualStyleBackColor = true;
            this.BtnActualizar.Click += new System.EventHandler(this.BtnActualizar_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.BtnCancelar.Location = new System.Drawing.Point(274, 274);
            this.BtnCancelar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(69, 24);
            this.BtnCancelar.TabIndex = 30;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            // 
            // LVExpedientes
            // 
            this.LVExpedientes.AutoArrange = false;
            this.LVExpedientes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1});
            this.LVExpedientes.Font = new System.Drawing.Font("Courier New", 8.142858F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LVExpedientes.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.LVExpedientes.HideSelection = false;
            this.LVExpedientes.Location = new System.Drawing.Point(11, 27);
            this.LVExpedientes.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.LVExpedientes.MultiSelect = false;
            this.LVExpedientes.Name = "LVExpedientes";
            this.LVExpedientes.ShowGroups = false;
            this.LVExpedientes.Size = new System.Drawing.Size(493, 243);
            this.LVExpedientes.TabIndex = 31;
            this.LVExpedientes.UseCompatibleStateImageBehavior = false;
            this.LVExpedientes.View = System.Windows.Forms.View.List;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Width = 700;
            // 
            // FrmExpedientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.BtnCancelar;
            this.ClientSize = new System.Drawing.Size(520, 305);
            this.Controls.Add(this.LVExpedientes);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnActualizar);
            this.Controls.Add(this.LblAviso);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.MaximizeBox = false;
            this.Name = "FrmExpedientes";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Expedientes";
            this.Load += new System.EventHandler(this.FrmExpedientes_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label LblAviso;
        private System.Windows.Forms.Button BtnActualizar;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.ListView LVExpedientes;
        private System.Windows.Forms.ColumnHeader columnHeader1;
    }
}