﻿using Entity;
using Microsoft.VisualBasic.FileIO;
using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace ArchivoHistorico
{
    public partial class FrmExpedientes : Form
    {
        public FrmExpedientes()
        {
            InitializeComponent();
        }

        private void BtnActualizar_Click(object sender, EventArgs e)
        {
            string archivoExpedientes = Path.GetFullPath(Path.Combine(Utilerias.directorio, "_expedientes.csv"));
            if (!File.Exists(@archivoExpedientes))
            {
                LblAviso.Text = "No se encontró archivo " + archivoExpedientes;
                return;
            }

            Cursor.Current = Cursors.WaitCursor;
            
            using (TextFieldParser csvReader = new TextFieldParser(@archivoExpedientes))
            {
                csvReader.SetDelimiters(new string[] { "," });
                csvReader.HasFieldsEnclosedInQuotes = true;

                // Skip the row with the column names
                csvReader.ReadLine();

                while (!csvReader.EndOfData)
                {
                    // Read current line fields, pointer moves to the next line.
                    string[] fields = csvReader.ReadFields();
                    if (fields.Count() >= 4)
                    {
                        string folioEntrega = fields[0];

                        string fechaInicio = fields[2]; // DD/MM/AAAA
                        string anio = fechaInicio.Substring(6, 4); // AAAAA
                        string mes  = anio + fechaInicio.Substring(3, 2); // MM
                        
                        string anioFolio = anio + Utilerias.FolioEntregaD6(folioEntrega);

                        DbExpediente dbExpediente = new DbExpediente();
                        dbExpediente.anioFolio = anioFolio;
                        dbExpediente.folioEntrega = folioEntrega;
                        dbExpediente.expedienteDGAA = fields[1];
                        dbExpediente.f_ini = Utilerias.FormatoFecha(fechaInicio);
                        dbExpediente.f_fin = Utilerias.FormatoFecha(fields[3]);
                        dbExpediente.anio = anio;
                        dbExpediente.mes = mes;
                        DbExpedientes.Insert(dbExpediente);
                    }
                }
            }
            Cursor.Current = Cursors.Default;
            MessageBox.Show("Se leyó el archivo " + archivoExpedientes,"Archivo Histórico", MessageBoxButtons.OK);
            this.Close();
        }
        private void FrmExpedientes_Load(object sender, EventArgs e)
        {
            LVExpedientes.View = View.Details;
            LVExpedientes.HeaderStyle = ColumnHeaderStyle.None;

            string archivoExpedientes = Path.GetFullPath(Path.Combine(Utilerias.directorio, "_expedientes.csv"));
            if (!File.Exists(@archivoExpedientes))
            {
                LblAviso.Text = "No se encontró archivo " + archivoExpedientes;
                return;
            }
            LblAviso.Text = "Se lee archivo " + archivoExpedientes;
            Cursor.Current = Cursors.WaitCursor;
            using (TextFieldParser csvReader = new TextFieldParser(@archivoExpedientes))
            {
                csvReader.SetDelimiters(new string[] { "," });
                csvReader.HasFieldsEnclosedInQuotes = true;

                // Skip the row with the column names
                while (!csvReader.EndOfData)
                {
                    string s = "";
                    // Read current line fields, pointer moves to the next line.
                    string[] fields = csvReader.ReadFields();
                    foreach (var field in fields) { 
                        s += field;
                        s += "     ";
                    }
                    LVExpedientes.Items.Add(s);
                }
            }
            Cursor.Current = Cursors.Default;
        }
    }
}
