﻿using Entity;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Utilities;

namespace ArchivoHistorico
{
    partial class FrmSacarHistorico : Form
    {
        public FrmSacarHistorico()
        {
            InitializeComponent();
            this.labelVersion.Text = "";
        }

        #region Assembly Attribute Accessors

        public string AssemblyTitle
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyTitleAttribute), false);
                if (attributes.Length > 0)
                {
                    AssemblyTitleAttribute titleAttribute = (AssemblyTitleAttribute)attributes[0];
                    if (titleAttribute.Title != "")
                    {
                        return titleAttribute.Title;
                    }
                }
                return System.IO.Path.GetFileNameWithoutExtension(Assembly.GetExecutingAssembly().CodeBase);
            }
        }

        public string AssemblyVersion
        {
            get
            {
                return Assembly.GetExecutingAssembly().GetName().Version.ToString();
            }
        }

        public string AssemblyDescription
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyDescriptionAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyDescriptionAttribute)attributes[0]).Description;
            }
        }

        public string AssemblyProduct
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyProductAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyProductAttribute)attributes[0]).Product;
            }
        }

        public string AssemblyCopyright
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCopyrightAttribute)attributes[0]).Copyright;
            }
        }

        public string AssemblyCompany
        {
            get
            {
                object[] attributes = Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCompanyAttribute), false);
                if (attributes.Length == 0)
                {
                    return "";
                }
                return ((AssemblyCompanyAttribute)attributes[0]).Company;
            }
        }
        #endregion

        private void FrmAboutBox_Load(object sender, EventArgs e)
        {
        }

        private void BtnSacarHistorico_Click(object sender, EventArgs e)
        {
            DbExpediente dbExpediente = DbExpedientes.GetExpedienteDGAA(txtExpedienteDGAA.Text);

            if (dbExpediente == null)
            {
                MessageBox.Show("Expediente DGAA no encontrado", "Aviso", MessageBoxButtons.OK);
                return;
            }
            if (MessageBox.Show($"El expediente DGAA {txtExpedienteDGAA.Text} se va a sacar del histórico. ¿Está de acuerdo?", "Sacar del Histórico", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
            {
                DbExpedientes.Delete(dbExpediente.anioFolio);
                // Se intenta renombrar archivo historico 
                string anioFolio = Convert.ToInt32(dbExpediente.anioFolio).ToString("D6");
                string pathHistorico = Path.Combine(Utilerias.historico, dbExpediente.anio, anioFolio + ".zip");
                string pathHistoricoRemovido = pathHistorico.Replace(".zip", ".removido");
                // Se trata de eliminar al directorio del expediente
                try
                {
                    File.Move(pathHistorico, pathHistoricoRemovido);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"No fué posible renombrar el archivo {pathHistorico}. Error: {ex.Message}",
                        "Error al tratar de renombrar archivo", MessageBoxButtons.OK);
                }
                MessageBox.Show("El expediente DGAA se sacó del Histórico");
            }
        }
    }
}
