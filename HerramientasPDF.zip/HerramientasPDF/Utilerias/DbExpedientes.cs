﻿using ArchivoHistorico;
using System;
using System.Data.SQLite;
using System.IO;
using System.Text;
using Utilities;

namespace Entity
{
    public class DbExpediente
    {
        public string anioFolio { get; set; }
        public string folioEntrega { get; set; }
        public string expedienteDGAA { get; set; }
        public string f_ini { get; set; }
        public string f_fin { get; set; }
        public string procesado { get; set; }
        public string anio { get; set; }
        public string mes { get; set; }
        public string checksum { get; set; }
        public string f_his { get; set; }
        public string mes_his { get; set; } 

        public DbExpediente()
        {
            anioFolio = "";
            folioEntrega = "";
            expedienteDGAA = "";
            f_ini = "";
            f_fin = "";
            procesado = "";
            anio = "";
            mes = "";
            checksum = "";
            f_his = "";
            mes_his = "";
        }
        public DbExpediente(SQLiteDataReader reader)
        {
            anioFolio = reader["anioFolio"].ToString();
            folioEntrega = reader["folioEntrega"].ToString();
            expedienteDGAA = reader["expedienteDGAA"].ToString();
            f_ini = reader["f_ini"].ToString();
            f_fin = reader["f_fin"].ToString();
            procesado = reader["procesado"].ToString();
            anio = reader["anio"].ToString();
            mes = reader["mes"].ToString();
            checksum = reader["checksum"].ToString();
            f_his = reader["f_his"].ToString();
            mes_his = reader["mes_his"].ToString();
        }
    }
    public class DbExpedientes
    {
        public static DbExpediente GetExpedienteDGAA(string expedienteDGAA)
        {
            DbExpediente dbExpediente;
            string sql = $"Select * From Expedientes Where expedienteDGAA='{expedienteDGAA}'";
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                    dbExpediente = new DbExpediente(reader);
                else
                    dbExpediente = null;
            }
            return dbExpediente;
        }
        public static string AnioFolio(string nombre)
        {
            // Regresa null en caso de que no se pueda determinar
            // 012345678901234
            // 000001_A-AS1-2001-000001-ACT.zip
            if (nombre.Length < 15)
            {
                return null;
            }
            string _folioEntrega = nombre.Substring(0, 6);
            int folioEntrega;
            if ( ! Int32.TryParse(_folioEntrega, out folioEntrega))
            {
                return null;
            }
            string anio = "20" + nombre.Substring(13, 2); // TODO: verificar que diga 2019, 2020, 2021, etc.
            return anio + folioEntrega.ToString("D6");
        }
        public static DbExpediente Get(string anioFolio)
        {
            if (anioFolio == null)
                return null;
            string sql = $"Select * From Expedientes Where anioFolio='{anioFolio}'";
            DbExpediente dbExpediente;
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                    dbExpediente = new DbExpediente(reader);
                else
                    dbExpediente = null;
            }
            return dbExpediente;
        }
        public static int YaProcesado(string anioFolio)
        {
            int rslt = -1; // regresa -1 en caso de que el expediente no exista
            string sql = $"Select procesado From Expedientes Where anioFolio='{anioFolio}'";
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();
                if (reader.Read())
                    if (reader["procesado"].ToString() == "1")
                        rslt = 1;
                    else
                        rslt = 0;
            }
            return rslt;
        }
        public static void Insert(DbExpediente expediente)
        {
            string sql = "INSERT OR IGNORE INTO Expedientes(anioFolio, folioEntrega, expedienteDGAA, f_ini, f_fin, anio, mes) " +
                    "VALUES ('@anioFolio', @folioEntrega, '@expedienteDGAA', '@f_ini', '@f_fin', @anio, @mes)";

            sql = sql.Replace("@anioFolio", expediente.anioFolio);
            sql = sql.Replace("@folioEntrega", expediente.folioEntrega);
            sql = sql.Replace("@expedienteDGAA", Q(expediente.expedienteDGAA));
            sql = sql.Replace("@f_ini", Q(expediente.f_ini));
            sql = sql.Replace("@f_fin", Q(expediente.f_fin));
            sql = sql.Replace("@anio", expediente.anio);
            sql = sql.Replace("@mes", expediente.mes);
            Database.ExecuteNonQueryCmd(sql);
        }
        public static void Procesado(string anioFolio, string checksum, string f_his, string mes_his)
        {
            string sql = $"UPDATE Expedientes SET procesado=1, checksum='{checksum}' , f_his='{f_his}' , mes_his={mes_his} WHERE anioFolio={anioFolio}";
            Database.ExecuteNonQueryCmd(sql);
        }
        public static void Delete(string anioFolio)
        {
            string sql = $"DELETE FROM Expedientes WHERE anioFolio='{anioFolio}'";
            Database.ExecuteNonQueryCmd(sql);
        }
        public static void Reporte(string reporte)
        {
            string sql = $"SELECT * FROM Expedientes WHERE procesado=1 ORDER BY folioEntrega";
            using (SQLiteConnection cn = new SQLiteConnection(Database.connectionString))
            {
                cn.Open();
                SQLiteCommand sqlCmd = new SQLiteCommand(sql, cn);
                SQLiteDataReader reader = sqlCmd.ExecuteReader();

                using (StreamWriter writetext = new StreamWriter(new FileStream(reporte, FileMode.Create), Encoding.UTF8))
                {
                    writetext.WriteLine("FolioEntrega,ExpedienteDGAA,Fecha Inicial,Fecha Final,Año,Mes,Fecha Histórico, Mes Histórico");
                    while (reader.Read())
                    {
                        DbExpediente d = new DbExpediente(reader);
                        writetext.WriteLine(String.Join(",", d.folioEntrega, d.expedienteDGAA, d.f_ini, d.f_fin, d.anio, d.mes, d.f_his, d.mes_his));
                    }
                }
            }
        }
        private static string Q(string s)
        {
            return s.Replace("'", "''").Trim();
        }
    }
}
