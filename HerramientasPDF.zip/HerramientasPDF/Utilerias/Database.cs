using System;
using System.Data;
using System.Data.Common;
using System.Data.SQLite;

namespace Utilities
{
    public static class Database
    {
        public static String connectionString;

        public static Object ExecuteScalarCmd(SQLiteCommand sqlCmd)
        {
            if (sqlCmd == null)
                throw (new ArgumentNullException("sqlCmd"));

            return ExecuteScalarCmd(sqlCmd, connectionString);
        }
        public static void ExecuteNonQueryCmd(string sql)
        {
            SQLiteCommand sqlCmd = new SQLiteCommand();
            Database.SetCommandType(sqlCmd, CommandType.Text, sql);
            Database.ExecuteScalarCmd(sqlCmd);
        }
        public static string ExecuteScalarCmd(string sql)
        {
            string result;

            SQLiteCommand sqlCmd = new SQLiteCommand();
            Database.SetCommandType(sqlCmd, CommandType.Text, sql);
            Object o = Database.ExecuteScalarCmd(sqlCmd);
            if (o == null)
                result = "";
            else
                result = o.ToString();
            return result;
        }
        private static Object ExecuteScalarCmd(SQLiteCommand sqlCmd, string connectionString)
        {
            // Validate Command Properties
            if (connectionString == null)
                throw (new ArgumentNullException("connectionString"));

            if (connectionString.Length == 0)
                throw (new ArgumentOutOfRangeException("connectionString"));

            if (sqlCmd == null)
                throw (new ArgumentNullException("sqlCmd"));

            Object result = null;
            using (SQLiteConnection cn = new SQLiteConnection(connectionString))
            {
                sqlCmd.Connection = cn;
                cn.Open();
                result = sqlCmd.ExecuteScalar();
            }
            return result;
        }
        public static void SetCommandType(DbCommand sqlCmd, CommandType cmdType, string cmdText)
        {
            if (cmdText == null)
                throw (new ArgumentNullException("cmdText"));

            if (sqlCmd == null)
                throw (new ArgumentNullException("sqlCmd"));

            sqlCmd.CommandType = cmdType;
            sqlCmd.CommandText = cmdText;
        }
    }
}
