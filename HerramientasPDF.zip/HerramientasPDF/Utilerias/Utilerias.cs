using System;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;

namespace ArchivoHistorico
{
    public static class Utilerias
    {
        public static string area;
        public static string directorio;
        public static string historico;
        public static string carpetas;

        public static string directorioUnzip;
        public static string directorioZip;
        public static string directorioTrabajo;

        public static string FondoSeccion;
        public static string Responsable;
        public static string ExpedienteGenerico;
        public static string TipoDeClasificacion;
        public static string ArchivoDeTramite;
        public static string ValorDocumental;
        public static string ArchivoConcentracion;
        public static string ValorHistorico;
        public static string TecnicasDeSeleccion;
        public static string TipoRequerimiento;
        public static string CambiaPorDGA;
        public static string PersonaResponsable;

        public static void LeeConfiguracion()
        {
            // configuracion.txt
            string[] linesConfiguracion = System.IO.File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), "configuracion.txt"));
            foreach (string line in linesConfiguracion)
            {
                string[] v = line.Split(';');
                if (v.Length >= 2)
                {
                    if (v[0] == "area")
                        Utilerias.area = v[1];
                    else if (v[0] == "directorio")
                        Utilerias.directorio = v[1];
                    else if (v[0] == "historico")
                        Utilerias.historico = v[1];
                    else if (v[0] == "carpetas")
                        Utilerias.carpetas = v[1];
                }
            }
            directorio = Path.GetFullPath(directorio);
            historico = Path.GetFullPath(historico);
            carpetas = Path.GetFullPath(carpetas);
            // caratula.txt
            string[] lines = System.IO.File.ReadAllLines(Path.Combine(Directory.GetCurrentDirectory(), "caratula.txt"));
            foreach (string line in lines)
            {
                string[] v = line.Split(';');
                if (v.Length >= 2)
                {
                    if (v[0] == "FondoSeccion")
                        Utilerias.FondoSeccion = v[1];
                    else if (v[0] == "Responsable")
                        Utilerias.Responsable = v[1];
                    else if (v[0] == "ExpedienteGenerico")
                        Utilerias.ExpedienteGenerico = v[1];
                    else if (v[0] == "TipoDeClasificacion")
                        Utilerias.TipoDeClasificacion = v[1];
                    else if (v[0] == "ArchivoDeTramite")
                        Utilerias.ArchivoDeTramite = v[1];
                    else if (v[0] == "ValorDocumental")
                        Utilerias.ValorDocumental = v[1];
                    else if (v[0] == "ArchivoConcentracion")
                        Utilerias.ArchivoConcentracion = v[1];
                    else if (v[0] == "ValorHistorico")
                        Utilerias.ValorHistorico = v[1];
                    else if (v[0] == "TecnicasDeSeleccion")
                        Utilerias.TecnicasDeSeleccion = v[1];
                    else if (v[0] == "TipoRequerimiento")
                        Utilerias.TipoRequerimiento = v[1];
                    else if (v[0] == "CambiaPorDGA")
                        Utilerias.CambiaPorDGA = v[1];
                    else if (v[0] == "PersonaResponsable")
                        Utilerias.PersonaResponsable = v[1];
                }
            }
        }
        public static string FormatoFecha(string fecha)
        {
            string dd = fecha.Substring(0, 2);
            string mm = fecha.Substring(3, 2);
            string aaaa = fecha.Substring(6, 4);
            return aaaa + mm + dd;
        }
        public static string FechaDDMMAAAA(string fecha)
        {
            string dd = fecha.Substring(6, 2);
            string mm = fecha.Substring(4, 2);
            string aaaa = fecha.Substring(0, 4);
            return dd + "/" + mm + "/" + aaaa;
        }
        public static string FolioEntregaD6(string _folio)
        {
            int folio;
            if (!Int32.TryParse(_folio, out folio))
            {
                return null;
            }
            return folio.ToString("D6");
        }
    }
}
