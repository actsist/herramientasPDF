﻿using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HerramientasPDF
{
    public static class HerramientasPDF
    {
        public static bool UnirPDF(List<string> lista, bool generaResumen, string nombreArchivoResumen)
        {
            string destinationFile = Path.Combine(Directory.GetCurrentDirectory(), "temp.tmp");
            System.IO.StreamWriter archivoResumen = null;
            if (generaResumen)
            {
                archivoResumen = new System.IO.StreamWriter(nombreArchivoResumen);
                string s = String.Format("{0,-50}{1}{2}{3}", "Archivos Foliados", "  #Páginas", "   Inicial", "     Final");
                archivoResumen.WriteLine(s);
            }

            bool merged = true;
            int paginaInicial = 1;

            using (FileStream stream = new FileStream(destinationFile, FileMode.Create))
            {
                using (Document document = new Document())
                {
                    PdfCopy pdf = new PdfCopy(document, stream);
                    try
                    {
                        document.Open();
                        foreach (string file in lista)
                        {
                            string sourceFile = Path.GetFileName(file);
                            using (var reader = new PdfReader(file))
                            {
                                if (generaResumen)
                                {
                                    string sPaginas = reader.NumberOfPages.ToString().PadLeft(10);
                                    string sPaginaInicial = paginaInicial.ToString().PadLeft(10);
                                    string sPaginaFinal = (paginaInicial + reader.NumberOfPages - 1).ToString().PadLeft(10);

                                    string s = String.Format("{0,-50}{1}{2}{3}", sourceFile, sPaginas, sPaginaInicial, sPaginaFinal);

                                    archivoResumen.WriteLine(s);

                                    paginaInicial += reader.NumberOfPages;
                                }
                                pdf.AddDocument(reader);
                                reader.Close();
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message);
                        merged = false;
                    }
                    finally
                    {
                        if (document != null)
                        {
                            document.Close();
                        }
                        if (generaResumen)
                        {
                            archivoResumen.Close();
                        }
                    }
                }
                stream.Close();
            }
            return merged;
        }

        public static bool PonerFolio(string destinationFile)
        {
            try
            {
                int folio = 0;
                var baseFont = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

                string sourceFile = Path.Combine(Directory.GetCurrentDirectory(), "temp.tmp");

                using (PdfReader reader = new PdfReader(sourceFile))
                using (Document document = new Document(PageSize.LETTER))
                using (PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(destinationFile, FileMode.Create, FileAccess.Write)))
                {
                    document.Open();

                    int n = reader.NumberOfPages;

                    for (int i = 1; i <= n; i++)
                    {
                        document.NewPage();

                        PdfImportedPage page = writer.GetImportedPage(reader, i);
                        PdfContentByte cb = writer.DirectContent;

                        int rotation = reader.GetPageRotation(i);
                        if (rotation == 90 || rotation == 270)
                        {
                            cb.AddTemplate(page, 0, -1f, 1f, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                        }
                        else
                        {
                            // cb.AddTemplate(page, 1f, 0, 0, 1f, 0, 0);
                            cb.AddTemplate(page, PageSize.LETTER.Width / reader.GetPageSize(i).Width, 0, 0,
                                                    PageSize.LETTER.Height / reader.GetPageSize(i).Height, 0, 0);
                        }

                        folio++;
                        cb.BeginText();
                        cb.SetFontAndSize(baseFont, 12);
                        cb.SetColorFill(BaseColor.RED);
                        cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, folio.ToString("D8"), 0, 0, 0);
                        cb.EndText();
                    }
                    document.Close();
                    reader.Close();
                }
                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error en archivo PDF {destinationFile}. {Environment.NewLine}El archivo de salida puede estar abierto, cierrelo. " + e.Message, "Error al escribir");
                return false;
            }
        }
    }
}
