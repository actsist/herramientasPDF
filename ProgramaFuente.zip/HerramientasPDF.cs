﻿using iTextSharp.awt.geom;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Crypto.Parameters;
using Org.BouncyCastle.Security;
using Org.BouncyCastle.X509;
using iTextSharp.text.pdf.security;
using Org.BouncyCastle.Crypto.Digests;
using Org.BouncyCastle.Utilities.Encoders;

namespace HerramientasPDF
{
    public static class HerramientasPDF
    {
        static string tempFile;
        static string tempIndiceFile;
        static string tempFoliado;
        static string tempPorFirmar;

        public static bool UnirPDF(List<string> lista)
        {
            tempFile = Path.Combine(Directory.GetCurrentDirectory(), "temp.pdf");
            tempIndiceFile = Path.Combine(Directory.GetCurrentDirectory(), "tempIndice.pdf");
            tempFoliado = Path.Combine(Directory.GetCurrentDirectory(), "tempFoliado.pdf");
            tempPorFirmar = Path.Combine(Directory.GetCurrentDirectory(), "tempPorFirmar.pdf");

            var listaIndice = new List<string>();
            string s = String.Format("{0,-66}{1}{2}{3}", "Archivos Foliados", "   Inicial", "     Final", "  #Páginas");
            listaIndice.Add(s);

            bool merged = true;
            int paginaInicial = 1;

            using (FileStream stream = new FileStream(tempFile, FileMode.Create))
            {
                var conc = new PdfConcatenate(stream, true);
                foreach (string file in lista)
                {
                    string sourceFile = Path.GetFileName(file);
                    using (var reader = new PdfReader(file))
                    {
                        string sPaginas = reader.NumberOfPages.ToString().PadLeft(10);
                        string sPaginaInicial = paginaInicial.ToString().PadLeft(10);
                        string sPaginaFinal = (paginaInicial + reader.NumberOfPages - 1).ToString().PadLeft(10);
                        s = String.Format("{0,-66}{1}{2}{3}", sourceFile.Substring(0, Math.Min(sourceFile.Length, 66)), sPaginaInicial, sPaginaFinal, sPaginas);
                        listaIndice.Add(s);

                        paginaInicial += reader.NumberOfPages;

                        conc.AddPages(reader);
                        reader.Close();
                    }
                }
                conc.Close();
                stream.Close();
            }

            using (System.IO.FileStream fs = new FileStream(tempIndiceFile, FileMode.Create, FileAccess.Write))
            {
                BaseFont bf = BaseFont.CreateFont(BaseFont.COURIER, BaseFont.CP1252, BaseFont.EMBEDDED);
                iTextSharp.text.Font font = new iTextSharp.text.Font(bf, 8);

                using (Document document = new Document(PageSize.LETTER, 10f, 10f, 50f, 10f))
                using (PdfWriter writer = PdfWriter.GetInstance(document, fs))
                {
                    document.Open();

                    Paragraph pEncabezado = new Paragraph();
                    Phrase phrase = new Phrase();
                    Chunk chunk = new Chunk("INDICE");
                    phrase.Add(chunk);
                    pEncabezado.Add(phrase);
                    pEncabezado.SpacingAfter = 5f;
                    pEncabezado.Alignment = Element.ALIGN_CENTER;
                    document.Add(pEncabezado);

                    PdfPTable tableDocs = new PdfPTable(1);
                    tableDocs.DefaultCell.Phrase = new Phrase() { Font = font };

                    for (int f = 0; f < listaIndice.Count(); f++)
                    {
                        string sourceFile = Path.GetFileName(listaIndice[f]);
                        string extension = Path.GetExtension(sourceFile);

                        PdfPCell cellDocumentos = new PdfPCell(new Phrase(sourceFile, font));
                        tableDocs.AddCell(cellDocumentos);
                    }
                    document.Add(tableDocs);

                    document.Close();
                    writer.Close();
                    fs.Close();
                }
            }
            return merged;
        }

        public static bool PonerFolio(bool foliar, bool conIndice)
        {
            try
            {
                int folio = 0;
                var baseFont = BaseFont.CreateFont(BaseFont.HELVETICA_BOLD, BaseFont.CP1252, BaseFont.NOT_EMBEDDED);

                using (PdfReader reader = new PdfReader(tempFile))
                using (Document document = new Document(PageSize.LETTER))
                using (PdfWriter writer = PdfWriter.GetInstance(document, new FileStream(tempFoliado, FileMode.Create, FileAccess.Write)))
                {
                    document.Open();

                    int n = reader.NumberOfPages;

                    for (int i = 1; i <= n; i++)
                    {
                        document.NewPage();

                        PdfImportedPage page = writer.GetImportedPage(reader, i);
                        PdfContentByte cb = writer.DirectContent;

                        float width = page.Width;
                        float height = page.Height;
                        if (width > height)
                        {
                            float scaleX = PageSize.LETTER.Width / width;
                            float scaleY = PageSize.LETTER.Height / height;
                            float scale = Math.Min(scaleX, scaleY);
                            AffineTransform transform = new AffineTransform(scale, 0, 0, scale, 0, 0);
                            double my = (PageSize.LETTER.Height / 2) - (height*scale / 4);
                            transform.Translate(0,my);
                            cb.AddTemplate(page, transform);
                        }
                        else
                        {
                            int rotation = reader.GetPageRotation(i);
                            if (rotation == 90 || rotation == 270)
                            {
                                cb.AddTemplate(page, 0, -1f, 1f, 0, 0, reader.GetPageSizeWithRotation(i).Height);
                            }
                            else
                            {
                                cb.AddTemplate(page, PageSize.LETTER.Width / reader.GetPageSize(i).Width, 0, 0,
                                                        PageSize.LETTER.Height / reader.GetPageSize(i).Height, 0, 0);
                            }
                        }
                        folio++;
                        if (foliar)
                        {
                            cb.BeginText();
                            cb.SetFontAndSize(baseFont, 12);
                            cb.SetColorFill(BaseColor.RED);
                            cb.ShowTextAligned(PdfContentByte.ALIGN_LEFT, folio.ToString("D8"), 0, 0, 0);
                            cb.EndText();
                        }
                    }
                    document.Close();
                    reader.Close();
                }

                using (FileStream stream = new FileStream(tempPorFirmar, FileMode.Create))
                {
                    var conc = new PdfConcatenate(stream, true);
                    if (conIndice)
                    {
                        using (var reader = new PdfReader(tempIndiceFile))
                        {
                            conc.AddPages(reader);
                            reader.Close();
                        }
                    }
                    using (var reader = new PdfReader(tempFoliado))
                    {
                        conc.AddPages(reader);
                        reader.Close();
                    }
                    conc.Close();
                    stream.Close();
                }

                return true;
            }
            catch (Exception e)
            {
                MessageBox.Show($"Error en archivo PDF {tempPorFirmar}. {Environment.NewLine}El archivo de salida puede estar abierto, cierrelo. " + e.Message, "Error al escribir");
                return false;
            }
        }
        public static bool Copiar(string destinationFile)
        {
            try
            {
                File.Copy(tempPorFirmar, destinationFile, true);
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error en archivo PDF {destinationFile}. {Environment.NewLine}El archivo de salida puede estar abierto, cierrelo. \n" + ex.Message, "Error al escribir");
                return false;
            }
        }
        public static string Md5(string input)
        {
            var data = System.Text.Encoding.UTF8.GetBytes(input);
            MD5Digest hash = new MD5Digest();
            hash.BlockUpdate(data, 0, data.Length);
            byte[] result = new byte[hash.GetDigestSize()];
            hash.DoFinal(result, 0);
            return Hex.ToHexString(result);
        }
        public static bool Firmar(string destinationFile, string cerFileName, string keyFileName, string pass)
        {
            try
            {
                // Se calcula hash para reportar
                string fileContents;
                using (StreamReader archivoPDF = new StreamReader(tempPorFirmar))
                {
                    fileContents = archivoPDF.ReadToEnd();
                }
                string resumenDigital = Md5(fileContents);
                // Llave privada
                byte[] dataKey = File.ReadAllBytes(keyFileName);
                AsymmetricKeyParameter privateKey = PrivateKeyFactory.DecryptKey(pass.ToCharArray(), dataKey);
                RsaPrivateCrtKeyParameters parameters = privateKey as RsaPrivateCrtKeyParameters;
                // Certificado
                byte[] cerdataKey = File.ReadAllBytes(cerFileName);
                var certificate = new Org.BouncyCastle.X509.X509CertificateParser().ReadCertificate(cerdataKey);
                // Obtener CN y OU del certificado
                var subjectCN = certificate.SubjectDN.GetValueList();
                string firmante = subjectCN[0].ToString();

                ICollection<X509Certificate> chain = new List<X509Certificate>();
                chain.Add(certificate);
                // Crea el reader y stamper
                using (PdfReader reader = new PdfReader(tempPorFirmar)) {
                    FileStream os = new FileStream(destinationFile, FileMode.Create);
                    PdfStamper stamper = PdfStamper.CreateSignature(reader, os, '\0');
                    // página al final
                    int numeroPaginas = reader.NumberOfPages + 1;
                    stamper.InsertPage(numeroPaginas, PageSize.LETTER);
                    // Crea la apariencia
                    PdfSignatureAppearance appearance = stamper.SignatureAppearance;
                    appearance.Reason = "Archivo PDF Firmado para enviar";
                    appearance.SetVisibleSignature(new iTextSharp.text.Rectangle(100, 650, 500, 750), numeroPaginas, "efirma");

                    PdfTemplate n0 = appearance.GetLayer(0);
                    float x = n0.BoundingBox.Left;
                    float y = n0.BoundingBox.Bottom;
                    float width = n0.BoundingBox.Width;
                    float height = n0.BoundingBox.Height;
                    n0.SetColorFill(BaseColor.LIGHT_GRAY);
                    n0.Rectangle(x, y, width, height);
                    n0.Fill();
                    // Creating the appearance for layer 2
                    PdfTemplate n2 = appearance.GetLayer(2);
                    ColumnText ct = new ColumnText(n2);
                    ct.SetSimpleColumn(n2.BoundingBox);
                    Paragraph p = new Paragraph("Documento firmado digitalmente.\nSu validación requiere un programa de computadora.");
                    ct.AddElement(p);
                    Paragraph pFecha = new Paragraph("Fecha y Hora de Firma: " + appearance.SignDate.ToString("dd/MM/yyyy HH:mm"));
                    ct.AddElement(pFecha);
                    Paragraph pFirmante = new Paragraph("Firmante: " + firmante);
                    ct.AddElement(pFirmante);
                    Paragraph pResumenDigital = new Paragraph("Resumen Digital: " + resumenDigital);
                    ct.AddElement(pResumenDigital);
                    Paragraph pAviso = new Paragraph("Presione aquí para ver e.firma");
                    ct.AddElement(pAviso);
                    ct.Go();

                    // Crea la firma
                    IExternalSignature pks = new PrivateKeySignature(parameters, DigestAlgorithms.SHA256);
                    MakeSignature.SignDetached(appearance, pks, chain, null, null, null, 0, CryptoStandard.CMS);
                }
                return true;
            }
            catch (Exception ex)
            {
                if (ex.Message.Substring(0, 3).ToLower() == "pad")
                {
                    MessageBox.Show($"Error de contraseña de Clave privada\n" + ex.Message, "Error al escribir");
                    return false;
                }
                else
                {
                    MessageBox.Show($"Error en archivo PDF {destinationFile}. {Environment.NewLine}El archivo de salida puede estar abierto, cierrelo. \n" + ex.Message, "Error al escribir");
                    return false;
                }
            }
        }

    }
}
