﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerramientasPDF
{
    public static class Utilerias
    {
        public static string directorio;

        public static void LeeConfiguracion()
        {
            string configuracionTXT = Path.Combine(Directory.GetCurrentDirectory(), "configuracion.txt");
            if (File.Exists(configuracionTXT))
            {
                string[] linesConfiguracion = System.IO.File.ReadAllLines(configuracionTXT);
                foreach (string line in linesConfiguracion)
                {
                    string[] v = line.Split(';');
                    if (v.Length >= 2)
                    {
                        if (v[0] == "directorio")
                            Utilerias.directorio = v[1];
                    }
                }
                try
                {
                    directorio = Path.GetFullPath(directorio);
                }
                catch
                {
                    directorio = "";
                }
            }
            else
                directorio = "";
        }

        public static void EscribeConfiguracion()
        {
            string configuracionTXT = Path.Combine(Directory.GetCurrentDirectory(), "configuracion.txt");
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(configuracionTXT))
            {
                file.WriteLine("directorio;" + directorio);
            }
        }
    }
}