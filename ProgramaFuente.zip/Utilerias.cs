﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HerramientasPDF
{
    public static class Utilerias
    {
        public static string directorio;
        public static string pathCertificado;
        public static string pathClavePrivada;
        public static bool foliar;
        public static bool indice;
        public static bool firmar;

        public static void LeeConfiguracion()
        {
            string configuracionTXT = Path.Combine(Directory.GetCurrentDirectory(), "configuracion.txt");
            if (File.Exists(configuracionTXT))
            {
                string[] linesConfiguracion = System.IO.File.ReadAllLines(configuracionTXT);
                foreach (string line in linesConfiguracion)
                {
                    string[] v = line.Split(';');
                    if (v.Length >= 2)
                    {
                        if (v[0] == "directorio")
                            Utilerias.directorio = v[1];
                        if (v[0] == "pathCertificado")
                            Utilerias.pathCertificado = v[1];
                        if (v[0] == "pathClavePrivada")
                            Utilerias.pathClavePrivada = v[1];
                        if (v[0] == "foliar")
                            Utilerias.foliar = (v[1]=="S");
                        if (v[0] == "indice")
                            Utilerias.indice = (v[1] == "S");
                        if (v[0] == "firmar")
                            Utilerias.firmar = (v[1] == "S");
                    }
                }
                try
                {
                    directorio = Path.GetFullPath(directorio);
                }
                catch
                {
                    directorio = "";
                }
                try
                {
                    pathCertificado = Path.GetFullPath(pathCertificado);
                }
                catch
                {
                    pathCertificado = "";
                }
                try
                {
                    pathClavePrivada = Path.GetFullPath(pathClavePrivada);
                }
                catch
                {
                    pathClavePrivada = "";
                }
            }
            else
            {
                directorio = "";
                pathCertificado = "";
                pathClavePrivada = "";
                foliar = true;
                indice = true;
                firmar = true;
            }
        }

        public static void EscribeConfiguracion()
        {
            string configuracionTXT = Path.Combine(Directory.GetCurrentDirectory(), "configuracion.txt");
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(configuracionTXT))
            {
                file.WriteLine("directorio;" + directorio);
                file.WriteLine("pathCertificado;" + pathCertificado);
                file.WriteLine("pathClavePrivada;" + pathClavePrivada);
                file.WriteLine("foliar;" + (foliar ? "S" : "N"));
                file.WriteLine("indice;" + (indice ? "S" : "N"));
                file.WriteLine("firmar;" + (firmar ? "S" : "N"));
            }
        }
    }
}