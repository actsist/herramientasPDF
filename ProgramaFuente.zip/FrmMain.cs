﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace HerramientasPDF
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void Btn_ArchivoEntrada_Click(object sender, EventArgs e)
        {
            DialogoEntradas.InitialDirectory = Utilerias.directorio;
            DialogoEntradas.FilterIndex = 0;

            if (DialogoEntradas.ShowDialog() == DialogResult.OK)
            {
                string selectedFileName = DialogoEntradas.FileName;
                Utilerias.directorio = Path.GetDirectoryName(selectedFileName);

                foreach (String archivo in DialogoEntradas.FileNames)
                {
                    // Si archivo NO esta en lista se incluye
                    if (listaArchivos.FindStringExact(archivo) == ListBox.NoMatches)
                        listaArchivos.Items.Add(archivo);
                }
            }
            else
            {
                TxtArchivoSalida.Text = "";
            }
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            Utilerias.LeeConfiguracion(); // se lee archivo configuracion.txt
            TxtArchivoCertificado.Text = Utilerias.pathCertificado;
            TxtArchivoClavePrivada.Text = Utilerias.pathClavePrivada;
            ChkFoliar.Checked = Utilerias.foliar;
            ChkIndice.Checked = Utilerias.indice;
            ChkFirmar.Checked = Utilerias.firmar;
            panelFirma.Visible = Utilerias.firmar;
            BtnArchivoEntrada.Select();
        }

        private void BtnUnir_Click(object sender, EventArgs e)
        {
            // Se validan algunas cosas
            if (TxtArchivoSalida.Text == "")
            {
                MessageBox.Show("Debe indicar el archivo de salida", "Aviso");
                return;
            }
            string extensionArchivoSalida = Path.GetExtension(TxtArchivoSalida.Text);
            if (extensionArchivoSalida.ToLower() != ".pdf")
            {
                MessageBox.Show("Archivo de salida debe tener extensión PDF\n" + TxtArchivoSalida.Text, "Aviso");
                return;
            }

            if (listaArchivos.Items.Count == 0)
            {
                MessageBox.Show("Debe indicar al menos un archivo para unir y/o foliar", "Aviso");
                return;
            }
            if (listaArchivos.FindStringExact(DialogoSalida.FileName) != ListBox.NoMatches)
            {
                MessageBox.Show("El archivo de salida no puede llamarse igual que alguno de los archivos de entrada\n" + DialogoSalida.FileName, "Aviso");
                return;
            }

            var archivosPDF = new List<string>();
            foreach (string archivo in listaArchivos.Items)
            {
                if (!System.IO.File.Exists(archivo))
                {
                    MessageBox.Show("Archivo de Entrada no encontrado\n" + archivo, "Aviso");
                    return;
                }
                string extension = Path.GetExtension(archivo);
                if (extension.ToLower() != ".pdf")
                {
                    MessageBox.Show("Archivo de Entrada debe tener extensión PDF\n" + archivo, "Aviso");
                    return;
                }
                archivosPDF.Add(archivo);
            }
            if (ChkFirmar.Checked)
            {
                if (!System.IO.File.Exists(TxtArchivoCertificado.Text))
                {
                    MessageBox.Show("Archivo de Certificado no encontrado\n" + TxtArchivoCertificado.Text, "Aviso");
                    return;
                }
                if (!System.IO.File.Exists(TxtArchivoClavePrivada.Text))
                {
                    MessageBox.Show("Archivo de Clave Privada no encontrado\n" + TxtArchivoClavePrivada.Text, "Aviso");
                    return;
                }
                if (TxtPassword.Text.Trim() == "")
                {
                    MessageBox.Show("Debe indicar contraseña de Clave Privada", "Aviso");
                    return;
                }
            }
            Cursor.Current = Cursors.WaitCursor;
            bool rsltOK = HerramientasPDF.UnirPDF(archivosPDF);
            if (rsltOK)
            {
                rsltOK = HerramientasPDF.PonerFolio(ChkFoliar.Checked, ChkIndice.Checked);

                if (rsltOK)
                {
                    if (ChkFirmar.Checked)
                        rsltOK = HerramientasPDF.Firmar(TxtArchivoSalida.Text, TxtArchivoCertificado.Text,
                                                TxtArchivoClavePrivada.Text, TxtPassword.Text);
                    else
                        rsltOK = HerramientasPDF.Copiar(TxtArchivoSalida.Text);
                }
                if (rsltOK)
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Archivo generado\n" + TxtArchivoSalida.Text, "Aviso");
                }
            }
            Cursor.Current = Cursors.Default;
        }
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Utilerias.EscribeConfiguracion();
        }

        private void BtnDialogoSalida_Click(object sender, EventArgs e)
        {
            if (DialogoSalida.ShowDialog() == DialogResult.OK)
            {
                // Si archivo NO esta en lista se incluye
                if (listaArchivos.FindStringExact(DialogoSalida.FileName) == ListBox.NoMatches)
                {
                    TxtArchivoSalida.Text = DialogoSalida.FileName;
                }
                else
                {
                    MessageBox.Show("El archivo de salida no puede llamarse igual que alguno de los archivos de entrada\n" + DialogoSalida.FileName, "Aviso");
                }
            }
        }

        private void BtnBorrarLista_Click(object sender, EventArgs e)
        {
            listaArchivos.Items.Clear();
        }

        private void BtnBorrarSeleccionados_Click(object sender, EventArgs e)
        {
            ListBox.SelectedObjectCollection selectedItems = new ListBox.SelectedObjectCollection(listaArchivos);

            if (listaArchivos.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    listaArchivos.Items.Remove(selectedItems[i]);
            }
            else
                MessageBox.Show("Debe seleccionar un archivo de la lista", "Aviso");

        }

        private void BtnArchivoCertificado_Click(object sender, EventArgs e)
        {
            if (DialogoArchivoCertificado.ShowDialog() == DialogResult.OK)
            {
                TxtArchivoCertificado.Text = DialogoArchivoCertificado.FileName;
                Utilerias.pathCertificado = DialogoArchivoCertificado.FileName;
            }
        }

        private void BtnArchivoClavePrivada_Click(object sender, EventArgs e)
        {
            if (DialogoArchivoClavePrivada.ShowDialog() == DialogResult.OK)
            {
                TxtArchivoClavePrivada.Text = DialogoArchivoClavePrivada.FileName;
                Utilerias.pathClavePrivada = DialogoArchivoClavePrivada.FileName;
            }
        }

        private void ChkFirmar_CheckedChanged(object sender, EventArgs e)
        {
            Utilerias.firmar = ChkFirmar.Checked;
            panelFirma.Visible = ChkFirmar.Checked;
        }

        private void ChkFoliar_CheckedChanged(object sender, EventArgs e)
        {
            Utilerias.foliar = ChkFoliar.Checked;
        }

        private void ChkIndice_CheckedChanged(object sender, EventArgs e)
        {
            Utilerias.indice = ChkIndice.Checked;
        }
    }
}
