﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Configuration;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HerramientasPDF
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void Btn_ArchivoEntrada_Click(object sender, EventArgs e)
        {
            DialogoEntradas.InitialDirectory = Utilerias.directorio;
            DialogoEntradas.FilterIndex = 0;

            if (DialogoEntradas.ShowDialog() == DialogResult.OK)
            {
                string selectedFileName = DialogoEntradas.FileName;
                Utilerias.directorio = Path.GetDirectoryName(selectedFileName);

                foreach (String archivo in DialogoEntradas.FileNames)
                {
                    // Si archivo NO esta en lista se incluye
                    if (listaArchivos.FindStringExact(archivo) == ListBox.NoMatches)
                        listaArchivos.Items.Add(archivo);
                }
            }
            else
            {
                TxtArchivoSalida.Text = "";
            }
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            Utilerias.LeeConfiguracion(); // se lee archivo configuracion.txt
        }

        private void BtnPonerFolio_Click(object sender, EventArgs e)
        {
            // Se validan algunas cosas
            if (TxtArchivoSalida.Text == "")
            {
                MessageBox.Show("Debe indicar el archivo de salida", "Aviso");
                return;
            }
            string extensionArchivoSalida = Path.GetExtension(TxtArchivoSalida.Text);
            if (extensionArchivoSalida.ToLower() != ".pdf")
            {
                MessageBox.Show("Archivo de salida debe tener extensión PDF\n" + TxtArchivoSalida.Text, "Aviso");
                return;
            }

            if (listaArchivos.Items.Count == 0)
            {
                MessageBox.Show("Debe indicar al menos un archivo para foliar", "Aviso");
                return;
            }
            if (listaArchivos.FindStringExact(DialogoSalida.FileName) != ListBox.NoMatches)
            {
                MessageBox.Show("El archivo de salida no puede llamarse igual que alguno de los archivos de entrada\n" + DialogoSalida.FileName, "Aviso");
                return;
            }

            var archivosPDF = new List<string>();
            foreach (string archivo in listaArchivos.Items)
            {
                if (!System.IO.File.Exists(archivo))
                {
                    MessageBox.Show("Archivo de Entrada no encontrado\n" + archivo, "Aviso");
                    return;
                }
                string extension = Path.GetExtension(archivo);
                if (extension.ToLower() != ".pdf")
                {
                    MessageBox.Show("Archivo de Entrada debe tener extensión PDF\n" + archivo, "Aviso");
                    return;
                }
                archivosPDF.Add(archivo);
            }
            Cursor.Current = Cursors.WaitCursor;
            if (HerramientasPDF.UnirPDF(archivosPDF, ChkResumen.Checked, TxtArchivoResumen.Text))
            {
                if (HerramientasPDF.PonerFolio(TxtArchivoSalida.Text))
                {
                    Cursor.Current = Cursors.Default;
                    MessageBox.Show("Archivo foliado generado\n" + TxtArchivoSalida.Text, "Aviso");
                }
            }
            Cursor.Current = Cursors.Default;
        }
        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Utilerias.EscribeConfiguracion();
        }

        private void BtnDialogoSalida_Click(object sender, EventArgs e)
        {
            if (DialogoSalida.ShowDialog() == DialogResult.OK)
            {
                // Si archivo NO esta en lista se incluye
                if (listaArchivos.FindStringExact(DialogoSalida.FileName) == ListBox.NoMatches)
                {
                    TxtArchivoSalida.Text = DialogoSalida.FileName;
                    NombreResumen();
                }
                else
                {
                    MessageBox.Show("El archivo de salida no puede llamarse igual que alguno de los archivos de entrada\n" + DialogoSalida.FileName, "Aviso");
                }
            }
        }

        private void BtnBorrarLista_Click(object sender, EventArgs e)
        {
            listaArchivos.Items.Clear();
        }

        private void BtnBorrarSeleccionados_Click(object sender, EventArgs e)
        {
            ListBox.SelectedObjectCollection selectedItems = new ListBox.SelectedObjectCollection(listaArchivos);
            selectedItems = listaArchivos.SelectedItems;

            if (listaArchivos.SelectedIndex != -1)
            {
                for (int i = selectedItems.Count - 1; i >= 0; i--)
                    listaArchivos.Items.Remove(selectedItems[i]);
            }
            else
                MessageBox.Show("Debe seleccionar un archivo de la lista", "Aviso");

        }

        private void ChkResumen_CheckedChanged(object sender, EventArgs e)
        {
            NombreResumen();
        }

        private void NombreResumen()
        {
            TxtArchivoResumen.Text = "";
            if (ChkResumen.Checked)
                if (TxtArchivoSalida.Text != "")
                {
                    string ruta = Path.GetDirectoryName(TxtArchivoSalida.Text);
                    string nombreArchivo = Path.GetFileNameWithoutExtension(TxtArchivoSalida.Text) + ".txt";
                    TxtArchivoResumen.Text = Path.Combine(ruta, nombreArchivo);
                }
        }
    }
}
