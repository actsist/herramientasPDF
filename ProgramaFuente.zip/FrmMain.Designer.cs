﻿namespace HerramientasPDF
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnArchivoEntrada = new System.Windows.Forms.Button();
            this.TxtArchivoSalida = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BtnPonerFolio = new System.Windows.Forms.Button();
            this.listaArchivos = new System.Windows.Forms.ListBox();
            this.DialogoSalida = new System.Windows.Forms.SaveFileDialog();
            this.DialogoEntradas = new System.Windows.Forms.OpenFileDialog();
            this.BtnDialogoSalida = new System.Windows.Forms.Button();
            this.BtnBorrarLista = new System.Windows.Forms.Button();
            this.BtnBorrarSeleccionados = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TxtArchivoResumen = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ChkResumen = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // BtnArchivoEntrada
            // 
            this.BtnArchivoEntrada.Location = new System.Drawing.Point(16, 15);
            this.BtnArchivoEntrada.Margin = new System.Windows.Forms.Padding(4);
            this.BtnArchivoEntrada.Name = "BtnArchivoEntrada";
            this.BtnArchivoEntrada.Size = new System.Drawing.Size(137, 68);
            this.BtnArchivoEntrada.TabIndex = 0;
            this.BtnArchivoEntrada.Text = "Seleccionar Archivos de Entrada";
            this.BtnArchivoEntrada.UseVisualStyleBackColor = true;
            this.BtnArchivoEntrada.Click += new System.EventHandler(this.Btn_ArchivoEntrada_Click);
            // 
            // TxtArchivoSalida
            // 
            this.TxtArchivoSalida.Location = new System.Drawing.Point(187, 311);
            this.TxtArchivoSalida.Margin = new System.Windows.Forms.Padding(4);
            this.TxtArchivoSalida.Name = "TxtArchivoSalida";
            this.TxtArchivoSalida.ReadOnly = true;
            this.TxtArchivoSalida.Size = new System.Drawing.Size(863, 22);
            this.TxtArchivoSalida.TabIndex = 2;
            this.TxtArchivoSalida.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(184, 290);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(122, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Archivo de Salida:";
            // 
            // BtnPonerFolio
            // 
            this.BtnPonerFolio.Location = new System.Drawing.Point(466, 433);
            this.BtnPonerFolio.Margin = new System.Windows.Forms.Padding(4);
            this.BtnPonerFolio.Name = "BtnPonerFolio";
            this.BtnPonerFolio.Size = new System.Drawing.Size(137, 64);
            this.BtnPonerFolio.TabIndex = 4;
            this.BtnPonerFolio.Text = "Unir y Foliar";
            this.BtnPonerFolio.UseVisualStyleBackColor = true;
            this.BtnPonerFolio.Click += new System.EventHandler(this.BtnPonerFolio_Click);
            // 
            // listaArchivos
            // 
            this.listaArchivos.FormattingEnabled = true;
            this.listaArchivos.ItemHeight = 16;
            this.listaArchivos.Location = new System.Drawing.Point(187, 47);
            this.listaArchivos.Margin = new System.Windows.Forms.Padding(4);
            this.listaArchivos.Name = "listaArchivos";
            this.listaArchivos.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listaArchivos.Size = new System.Drawing.Size(863, 212);
            this.listaArchivos.TabIndex = 5;
            // 
            // DialogoSalida
            // 
            this.DialogoSalida.DefaultExt = "pdf";
            this.DialogoSalida.Title = "Archivo Foliado";
            // 
            // DialogoEntradas
            // 
            this.DialogoEntradas.Filter = "Archivo Acrobat .pdf|*.pdf";
            this.DialogoEntradas.Multiselect = true;
            this.DialogoEntradas.RestoreDirectory = true;
            this.DialogoEntradas.Title = "Selección de Archivo PDF";
            // 
            // BtnDialogoSalida
            // 
            this.BtnDialogoSalida.Location = new System.Drawing.Point(16, 290);
            this.BtnDialogoSalida.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDialogoSalida.Name = "BtnDialogoSalida";
            this.BtnDialogoSalida.Size = new System.Drawing.Size(137, 68);
            this.BtnDialogoSalida.TabIndex = 6;
            this.BtnDialogoSalida.Text = "Archivo de Salida";
            this.BtnDialogoSalida.UseVisualStyleBackColor = true;
            this.BtnDialogoSalida.Click += new System.EventHandler(this.BtnDialogoSalida_Click);
            // 
            // BtnBorrarLista
            // 
            this.BtnBorrarLista.Location = new System.Drawing.Point(16, 196);
            this.BtnBorrarLista.Margin = new System.Windows.Forms.Padding(4);
            this.BtnBorrarLista.Name = "BtnBorrarLista";
            this.BtnBorrarLista.Size = new System.Drawing.Size(137, 63);
            this.BtnBorrarLista.TabIndex = 7;
            this.BtnBorrarLista.Text = "Quitar Todos los Archivos de Entrada";
            this.BtnBorrarLista.UseVisualStyleBackColor = true;
            this.BtnBorrarLista.Click += new System.EventHandler(this.BtnBorrarLista_Click);
            // 
            // BtnBorrarSeleccionados
            // 
            this.BtnBorrarSeleccionados.Location = new System.Drawing.Point(16, 104);
            this.BtnBorrarSeleccionados.Margin = new System.Windows.Forms.Padding(4);
            this.BtnBorrarSeleccionados.Name = "BtnBorrarSeleccionados";
            this.BtnBorrarSeleccionados.Size = new System.Drawing.Size(137, 63);
            this.BtnBorrarSeleccionados.TabIndex = 8;
            this.BtnBorrarSeleccionados.Text = "Quitar Archivos de Entrada Seleccionados";
            this.BtnBorrarSeleccionados.UseVisualStyleBackColor = true;
            this.BtnBorrarSeleccionados.Click += new System.EventHandler(this.BtnBorrarSeleccionados_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(184, 26);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(140, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Archivos de Entrada:";
            // 
            // TxtArchivoResumen
            // 
            this.TxtArchivoResumen.Location = new System.Drawing.Point(187, 379);
            this.TxtArchivoResumen.Margin = new System.Windows.Forms.Padding(4);
            this.TxtArchivoResumen.Name = "TxtArchivoResumen";
            this.TxtArchivoResumen.ReadOnly = true;
            this.TxtArchivoResumen.Size = new System.Drawing.Size(863, 22);
            this.TxtArchivoResumen.TabIndex = 10;
            this.TxtArchivoResumen.WordWrap = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(184, 358);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(123, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "Archivo Resumen:";
            // 
            // ChkResumen
            // 
            this.ChkResumen.AutoSize = true;
            this.ChkResumen.Location = new System.Drawing.Point(24, 375);
            this.ChkResumen.Name = "ChkResumen";
            this.ChkResumen.Size = new System.Drawing.Size(147, 21);
            this.ChkResumen.TabIndex = 12;
            this.ChkResumen.Text = "Generar Resumen";
            this.ChkResumen.UseVisualStyleBackColor = true;
            this.ChkResumen.CheckedChanged += new System.EventHandler(this.ChkResumen_CheckedChanged);
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 521);
            this.Controls.Add(this.ChkResumen);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TxtArchivoResumen);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnBorrarSeleccionados);
            this.Controls.Add(this.BtnBorrarLista);
            this.Controls.Add(this.BtnDialogoSalida);
            this.Controls.Add(this.listaArchivos);
            this.Controls.Add(this.BtnPonerFolio);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TxtArchivoSalida);
            this.Controls.Add(this.BtnArchivoEntrada);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HerramientasPDF 0.2";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnArchivoEntrada;
        private System.Windows.Forms.TextBox TxtArchivoSalida;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BtnPonerFolio;
        private System.Windows.Forms.ListBox listaArchivos;
        private System.Windows.Forms.SaveFileDialog DialogoSalida;
        private System.Windows.Forms.OpenFileDialog DialogoEntradas;
        private System.Windows.Forms.Button BtnDialogoSalida;
        private System.Windows.Forms.Button BtnBorrarLista;
        private System.Windows.Forms.Button BtnBorrarSeleccionados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxtArchivoResumen;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox ChkResumen;
    }
}

