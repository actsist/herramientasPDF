﻿namespace HerramientasPDF
{
    partial class FrmMain
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.BtnArchivoEntrada = new System.Windows.Forms.Button();
            this.TxtArchivoSalida = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.listaArchivos = new System.Windows.Forms.ListBox();
            this.DialogoSalida = new System.Windows.Forms.SaveFileDialog();
            this.DialogoEntradas = new System.Windows.Forms.OpenFileDialog();
            this.BtnDialogoSalida = new System.Windows.Forms.Button();
            this.BtnBorrarLista = new System.Windows.Forms.Button();
            this.BtnBorrarSeleccionados = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.BtnUnir = new System.Windows.Forms.Button();
            this.TxtArchivoCertificado = new System.Windows.Forms.TextBox();
            this.TxtArchivoClavePrivada = new System.Windows.Forms.TextBox();
            this.TxtPassword = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.BtnArchivoCertificado = new System.Windows.Forms.Button();
            this.BtnArchivoClavePrivada = new System.Windows.Forms.Button();
            this.DialogoArchivoCertificado = new System.Windows.Forms.OpenFileDialog();
            this.DialogoArchivoClavePrivada = new System.Windows.Forms.OpenFileDialog();
            this.panelFirma = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.ChkFirmar = new System.Windows.Forms.CheckBox();
            this.ChkFoliar = new System.Windows.Forms.CheckBox();
            this.ChkIndice = new System.Windows.Forms.CheckBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panelFirma.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // BtnArchivoEntrada
            // 
            this.BtnArchivoEntrada.Location = new System.Drawing.Point(13, 11);
            this.BtnArchivoEntrada.Margin = new System.Windows.Forms.Padding(4);
            this.BtnArchivoEntrada.Name = "BtnArchivoEntrada";
            this.BtnArchivoEntrada.Size = new System.Drawing.Size(137, 68);
            this.BtnArchivoEntrada.TabIndex = 0;
            this.BtnArchivoEntrada.Text = "Seleccionar Archivos de Entrada";
            this.BtnArchivoEntrada.UseVisualStyleBackColor = true;
            this.BtnArchivoEntrada.Click += new System.EventHandler(this.Btn_ArchivoEntrada_Click);
            // 
            // TxtArchivoSalida
            // 
            this.TxtArchivoSalida.Location = new System.Drawing.Point(179, 36);
            this.TxtArchivoSalida.Margin = new System.Windows.Forms.Padding(4);
            this.TxtArchivoSalida.Name = "TxtArchivoSalida";
            this.TxtArchivoSalida.ReadOnly = true;
            this.TxtArchivoSalida.Size = new System.Drawing.Size(891, 22);
            this.TxtArchivoSalida.TabIndex = 2;
            this.TxtArchivoSalida.TabStop = false;
            this.TxtArchivoSalida.WordWrap = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(180, 15);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(172, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "Indique Archivo de Salida:";
            // 
            // listaArchivos
            // 
            this.listaArchivos.FormattingEnabled = true;
            this.listaArchivos.ItemHeight = 16;
            this.listaArchivos.Location = new System.Drawing.Point(175, 32);
            this.listaArchivos.Margin = new System.Windows.Forms.Padding(4);
            this.listaArchivos.Name = "listaArchivos";
            this.listaArchivos.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
            this.listaArchivos.Size = new System.Drawing.Size(896, 228);
            this.listaArchivos.TabIndex = 3;
            // 
            // DialogoSalida
            // 
            this.DialogoSalida.DefaultExt = "pdf";
            this.DialogoSalida.Title = "Archivo Foliado";
            // 
            // DialogoEntradas
            // 
            this.DialogoEntradas.Filter = "Archivo Acrobat .pdf|*.pdf";
            this.DialogoEntradas.Multiselect = true;
            this.DialogoEntradas.RestoreDirectory = true;
            this.DialogoEntradas.Title = "Seleccione archivo PDF";
            // 
            // BtnDialogoSalida
            // 
            this.BtnDialogoSalida.Location = new System.Drawing.Point(12, 13);
            this.BtnDialogoSalida.Margin = new System.Windows.Forms.Padding(4);
            this.BtnDialogoSalida.Name = "BtnDialogoSalida";
            this.BtnDialogoSalida.Size = new System.Drawing.Size(137, 68);
            this.BtnDialogoSalida.TabIndex = 4;
            this.BtnDialogoSalida.Text = "Archivo de Salida";
            this.BtnDialogoSalida.UseVisualStyleBackColor = true;
            this.BtnDialogoSalida.Click += new System.EventHandler(this.BtnDialogoSalida_Click);
            // 
            // BtnBorrarLista
            // 
            this.BtnBorrarLista.Location = new System.Drawing.Point(13, 192);
            this.BtnBorrarLista.Margin = new System.Windows.Forms.Padding(4);
            this.BtnBorrarLista.Name = "BtnBorrarLista";
            this.BtnBorrarLista.Size = new System.Drawing.Size(137, 63);
            this.BtnBorrarLista.TabIndex = 2;
            this.BtnBorrarLista.Text = "Quitar Todos los Archivos de Entrada";
            this.BtnBorrarLista.UseVisualStyleBackColor = true;
            this.BtnBorrarLista.Click += new System.EventHandler(this.BtnBorrarLista_Click);
            // 
            // BtnBorrarSeleccionados
            // 
            this.BtnBorrarSeleccionados.Location = new System.Drawing.Point(13, 100);
            this.BtnBorrarSeleccionados.Margin = new System.Windows.Forms.Padding(4);
            this.BtnBorrarSeleccionados.Name = "BtnBorrarSeleccionados";
            this.BtnBorrarSeleccionados.Size = new System.Drawing.Size(137, 63);
            this.BtnBorrarSeleccionados.TabIndex = 1;
            this.BtnBorrarSeleccionados.Text = "Quitar Archivos de Entrada Seleccionados";
            this.BtnBorrarSeleccionados.UseVisualStyleBackColor = true;
            this.BtnBorrarSeleccionados.Click += new System.EventHandler(this.BtnBorrarSeleccionados_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(178, 11);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(223, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "Seleccione Archivo(s) de Entrada:";
            // 
            // BtnUnir
            // 
            this.BtnUnir.Location = new System.Drawing.Point(457, 8);
            this.BtnUnir.Margin = new System.Windows.Forms.Padding(4);
            this.BtnUnir.Name = "BtnUnir";
            this.BtnUnir.Size = new System.Drawing.Size(137, 64);
            this.BtnUnir.TabIndex = 8;
            this.BtnUnir.Text = "Procesar";
            this.BtnUnir.UseVisualStyleBackColor = true;
            this.BtnUnir.Click += new System.EventHandler(this.BtnUnir_Click);
            // 
            // TxtArchivoCertificado
            // 
            this.TxtArchivoCertificado.Location = new System.Drawing.Point(176, 59);
            this.TxtArchivoCertificado.Margin = new System.Windows.Forms.Padding(4);
            this.TxtArchivoCertificado.Name = "TxtArchivoCertificado";
            this.TxtArchivoCertificado.ReadOnly = true;
            this.TxtArchivoCertificado.Size = new System.Drawing.Size(891, 22);
            this.TxtArchivoCertificado.TabIndex = 15;
            this.TxtArchivoCertificado.TabStop = false;
            this.TxtArchivoCertificado.WordWrap = false;
            // 
            // TxtArchivoClavePrivada
            // 
            this.TxtArchivoClavePrivada.Location = new System.Drawing.Point(176, 135);
            this.TxtArchivoClavePrivada.Margin = new System.Windows.Forms.Padding(4);
            this.TxtArchivoClavePrivada.Name = "TxtArchivoClavePrivada";
            this.TxtArchivoClavePrivada.ReadOnly = true;
            this.TxtArchivoClavePrivada.Size = new System.Drawing.Size(891, 22);
            this.TxtArchivoClavePrivada.TabIndex = 16;
            this.TxtArchivoClavePrivada.TabStop = false;
            this.TxtArchivoClavePrivada.WordWrap = false;
            // 
            // TxtPassword
            // 
            this.TxtPassword.Location = new System.Drawing.Point(186, 199);
            this.TxtPassword.Name = "TxtPassword";
            this.TxtPassword.Size = new System.Drawing.Size(220, 22);
            this.TxtPassword.TabIndex = 11;
            this.TxtPassword.UseSystemPasswordChar = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 202);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 17);
            this.label6.TabIndex = 20;
            this.label6.Text = "Contraseña clave privada:";
            // 
            // BtnArchivoCertificado
            // 
            this.BtnArchivoCertificado.Location = new System.Drawing.Point(9, 36);
            this.BtnArchivoCertificado.Margin = new System.Windows.Forms.Padding(4);
            this.BtnArchivoCertificado.Name = "BtnArchivoCertificado";
            this.BtnArchivoCertificado.Size = new System.Drawing.Size(137, 68);
            this.BtnArchivoCertificado.TabIndex = 9;
            this.BtnArchivoCertificado.Text = "Archivo c/Certificado";
            this.BtnArchivoCertificado.UseVisualStyleBackColor = true;
            this.BtnArchivoCertificado.Click += new System.EventHandler(this.BtnArchivoCertificado_Click);
            // 
            // BtnArchivoClavePrivada
            // 
            this.BtnArchivoClavePrivada.Location = new System.Drawing.Point(9, 112);
            this.BtnArchivoClavePrivada.Margin = new System.Windows.Forms.Padding(4);
            this.BtnArchivoClavePrivada.Name = "BtnArchivoClavePrivada";
            this.BtnArchivoClavePrivada.Size = new System.Drawing.Size(137, 68);
            this.BtnArchivoClavePrivada.TabIndex = 10;
            this.BtnArchivoClavePrivada.Text = "Archivo c/clave Privada";
            this.BtnArchivoClavePrivada.UseVisualStyleBackColor = true;
            this.BtnArchivoClavePrivada.Click += new System.EventHandler(this.BtnArchivoClavePrivada_Click);
            // 
            // DialogoArchivoCertificado
            // 
            this.DialogoArchivoCertificado.Filter = "Archivo Certificado .cer|*.cer";
            this.DialogoArchivoCertificado.Title = "Seleccione archivo con certificado";
            // 
            // DialogoArchivoClavePrivada
            // 
            this.DialogoArchivoClavePrivada.Filter = "Archivo Clave Privada .key|*.key";
            this.DialogoArchivoClavePrivada.Title = "Seleccione archivo con clave privada";
            // 
            // panelFirma
            // 
            this.panelFirma.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.panelFirma.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFirma.Controls.Add(this.label3);
            this.panelFirma.Controls.Add(this.TxtPassword);
            this.panelFirma.Controls.Add(this.BtnArchivoClavePrivada);
            this.panelFirma.Controls.Add(this.TxtArchivoCertificado);
            this.panelFirma.Controls.Add(this.BtnArchivoCertificado);
            this.panelFirma.Controls.Add(this.TxtArchivoClavePrivada);
            this.panelFirma.Controls.Add(this.label6);
            this.panelFirma.Location = new System.Drawing.Point(15, 508);
            this.panelFirma.Name = "panelFirma";
            this.panelFirma.Size = new System.Drawing.Size(1074, 236);
            this.panelFirma.TabIndex = 23;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(428, 5);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(325, 17);
            this.label3.TabIndex = 23;
            this.label3.Text = "Datos de su certificado de firma electrónica";
            // 
            // ChkFirmar
            // 
            this.ChkFirmar.AutoSize = true;
            this.ChkFirmar.Location = new System.Drawing.Point(295, 31);
            this.ChkFirmar.Name = "ChkFirmar";
            this.ChkFirmar.Size = new System.Drawing.Size(70, 21);
            this.ChkFirmar.TabIndex = 7;
            this.ChkFirmar.Text = "Firmar";
            this.ChkFirmar.UseVisualStyleBackColor = true;
            this.ChkFirmar.CheckedChanged += new System.EventHandler(this.ChkFirmar_CheckedChanged);
            // 
            // ChkFoliar
            // 
            this.ChkFoliar.AutoSize = true;
            this.ChkFoliar.Location = new System.Drawing.Point(14, 31);
            this.ChkFoliar.Name = "ChkFoliar";
            this.ChkFoliar.Size = new System.Drawing.Size(65, 21);
            this.ChkFoliar.TabIndex = 5;
            this.ChkFoliar.Text = "Foliar";
            this.ChkFoliar.UseVisualStyleBackColor = true;
            this.ChkFoliar.CheckedChanged += new System.EventHandler(this.ChkFoliar_CheckedChanged);
            // 
            // ChkIndice
            // 
            this.ChkIndice.AutoSize = true;
            this.ChkIndice.Location = new System.Drawing.Point(145, 31);
            this.ChkIndice.Name = "ChkIndice";
            this.ChkIndice.Size = new System.Drawing.Size(96, 21);
            this.ChkIndice.TabIndex = 6;
            this.ChkIndice.Text = "Con Indice";
            this.ChkIndice.UseVisualStyleBackColor = true;
            this.ChkIndice.CheckedChanged += new System.EventHandler(this.ChkIndice_CheckedChanged);
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.TxtArchivoSalida);
            this.panel1.Controls.Add(this.BtnDialogoSalida);
            this.panel1.Location = new System.Drawing.Point(12, 295);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1076, 95);
            this.panel1.TabIndex = 28;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.listaArchivos);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.BtnArchivoEntrada);
            this.panel2.Controls.Add(this.BtnBorrarLista);
            this.panel2.Controls.Add(this.BtnBorrarSeleccionados);
            this.panel2.Location = new System.Drawing.Point(11, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1077, 270);
            this.panel2.TabIndex = 29;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.ChkFirmar);
            this.panel3.Controls.Add(this.ChkFoliar);
            this.panel3.Controls.Add(this.ChkIndice);
            this.panel3.Controls.Add(this.BtnUnir);
            this.panel3.Location = new System.Drawing.Point(241, 408);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(614, 83);
            this.panel3.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(11, 1);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(253, 17);
            this.label5.TabIndex = 28;
            this.label5.Text = "Marque las opciones del proceso:";
            // 
            // FrmMain
            // 
            this.AcceptButton = this.BtnUnir;
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1105, 757);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panelFirma);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HerramientasPDF 0.5    Une Archivos, Pone Folio, Genera Indice, Firma archivos PD" +
    "F";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.panelFirma.ResumeLayout(false);
            this.panelFirma.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtnArchivoEntrada;
        private System.Windows.Forms.TextBox TxtArchivoSalida;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox listaArchivos;
        private System.Windows.Forms.SaveFileDialog DialogoSalida;
        private System.Windows.Forms.OpenFileDialog DialogoEntradas;
        private System.Windows.Forms.Button BtnDialogoSalida;
        private System.Windows.Forms.Button BtnBorrarLista;
        private System.Windows.Forms.Button BtnBorrarSeleccionados;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BtnUnir;
        private System.Windows.Forms.TextBox TxtArchivoCertificado;
        private System.Windows.Forms.TextBox TxtArchivoClavePrivada;
        private System.Windows.Forms.TextBox TxtPassword;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BtnArchivoCertificado;
        private System.Windows.Forms.Button BtnArchivoClavePrivada;
        private System.Windows.Forms.OpenFileDialog DialogoArchivoCertificado;
        private System.Windows.Forms.OpenFileDialog DialogoArchivoClavePrivada;
        private System.Windows.Forms.Panel panelFirma;
        private System.Windows.Forms.CheckBox ChkFirmar;
        private System.Windows.Forms.CheckBox ChkFoliar;
        private System.Windows.Forms.CheckBox ChkIndice;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label5;
    }
}

